package level2.star;

//formatting the output with single space gap.
public class Triangle1C_Test2 {

	public static void main(String[] args) {

		int  totalRows = 7;  //number of rows to display
		int col ;
		
		//fill stars of size=totalRows,as star characters goes on decreases.
		StringBuilder rowBuilder = new StringBuilder();
		for(col = 1 ; col <= totalRows; col ++ ) {
			rowBuilder.append("* ");
		}
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			System.out.println();// move control to the next line where new set of characters will get printed.
			
			col = (totalRows + 1) - row  ;
			System.out.println(rowBuilder.substring(0, 2*col).toString());

		}

	}

}
