package strings;

public class SubStringPattern {

	public static void main(String[] args) {
		
		String str = "Programming";
		int index ;
		String subStr = "";
		int LENGTH = str.length();
		System.out.println( "Length of String  = " + LENGTH);
		System.out.println( "===================");
		for( index = 1 ; index <= LENGTH ; index++) {
			subStr = str.substring(0, index);
			System.out.println( subStr);
			
		}
		// using decrementing loop in a string
		for( index = LENGTH - 1; index >= 1 ; index -- ) {
			subStr = str.substring(0, index);
			System.out.println( subStr);
			
		}
		
	}

}
