package level1.number.pattern3;

public class TriangleD1_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 7;  //number of rows to display

		for( int row = totalRows ; row >=1  ; row -- ) {

			System.out.println();// move control to the next line where new set of characters will get printed.

			// spaces to be printed 
			for(int col = 1; col <= ( totalRows - row )    ; col++) {
				if( col  < 10) {
					System.out.print( "   " );  //3 spaces for 1 digit number
				}else {
					System.out.print( " " );  //1 spaces for 2 digit number
				}
				
			}
			// row value to be printed 
			for( int num= 2*row - 1 ; num>= row ; num -- ){
				if( num  < 10) {
					System.out.print( "  " + num  );  //2 spaces for 1 digit number
				}else {
					System.out.print( " " + num);  //1 spaces for 2 digit number
				}
			}

		}
	}
}
