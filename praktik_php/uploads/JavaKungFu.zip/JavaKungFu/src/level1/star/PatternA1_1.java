package level1.star;

public class PatternA1_1 {
	public static void main(String[] args) {		
		System.out.print("*"); // print 1 time
		System.out.println(); // Move cursor to the next row
		System.out.print("*");System.out.print("*");//print 2 times
		System.out.println();// Move cursor to the next row
		System.out.print("*");System.out.print("*");
		System.out.print("*");// print 3 times
		System.out.println();// Move cursor to the next row
		System.out.print("*");System.out.print("*");
		System.out.print("*");System.out.print("*");//print 4 times
		System.out.println();// Move cursor to the next row
		System.out.print("*");System.out.print("*");
		System.out.print("*");System.out.print("*");
		System.out.print("*");//print 5 times
		System.out.println();// Move cursor to the next row
	}
}
