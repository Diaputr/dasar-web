package strings;

public class StringConcat {

	public static void main( String[] args ) {
		
		String name  = "Steve" + " " + "Jobs";
		String name1 = "Steve";
		String name2 = "Jobs";
		
		System.out.println( name  );
		System.out.println( "X -> Common mistake while using concat()" );
		// no assignment operator is being used to store the final result
		name1.concat(" ");
		name1.concat( name2 );
		System.out.println( name1  );//common mistake 
		System.out.println(  "Correct use of concat() " );
		// don't forget to use assignment operator just like 
		// we had used in case of numeric calculations
		name1 = name1.concat(" ");
		name1 = name1.concat( name2 );
		System.out.println( name1 );

	}

}
