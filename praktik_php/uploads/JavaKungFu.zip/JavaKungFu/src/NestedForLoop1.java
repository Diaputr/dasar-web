public class NestedForLoop1 {

	public static void main(String[] args) {

		for ( int counter = 5 ; counter >= 1; counter -- ){
			// print the variable counter�s value	
			System.out.println( counter );  //statement1
			//The for-loop is a statement2
			for(int inner = 1 ; inner <= 5; inner ++){
				System.out.println( inner );
		      }
			System.out.println( 3*counter );//statement3

		}
	}

}

