package level3.reuseLogic;

import level1.star.TriangleB;
import level1.star.TriangleD;


public class ExerciseDD {

	public static void main(String[] args) {
		int totalRows = 10;
		
		
		TriangleD.draw(totalRows);
		TriangleB.draw(totalRows);

	}

}
