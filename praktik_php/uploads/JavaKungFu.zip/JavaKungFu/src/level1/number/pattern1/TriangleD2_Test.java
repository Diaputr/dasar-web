package level1.number.pattern1;

public class TriangleD2_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 7;  //number of rows to display

		for( int row = totalRows ; row >=1  ; row -- ) {

			System.out.println();// move control to the next line where new set of characters will get printed.

			for(int col = 1; col <= ( totalRows  )    ; col++) {
				if( col <= ( totalRows - row ) ) {
					System.out.print( "  " );  // spaces to be printed 
				}else {
					System.out.print( row + " " );  // row value to be printed 
				}

			}
		}
	}
}
