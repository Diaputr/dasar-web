
/*
 * This is my first program.
 * Program to print welcome message.
 */
public class Welcome {

	public static void main( String[] args ) {
		// program logic goes here
		System.out.println("Welcome to Java Programming.");
	}

}
