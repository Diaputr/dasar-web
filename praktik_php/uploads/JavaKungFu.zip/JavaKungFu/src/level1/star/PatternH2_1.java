package level1.star;
public class PatternH2_1 {
	public static void main(String[] args) {
		
		int  totalRows = 4;  //number of rows to display
		
		// Row level Repetitive Action : 
		// Action1.Execute's Column level Repetitive Action 
		// Action2.Move cursor to next row.
		for( int row = 1 ; row <= ( 2* totalRows - 1 ) ; row ++ ) {

			//1st half : Column level Repetitive Action : 
			if(  row <= totalRows ) {
				
				for(int col = 1 ; col <= ( totalRows  + row -1 ) ; col++) {
					if( col >= ( totalRows  -  row  + 1 )  ) {
						System.out.print("* ");  
					}else {
						System.out.print("  ");  
					}
					
				}//inner for-loop_1
			}					

			// 2nd half : Column level Repetitive Action : 
			if( row >totalRows ) {
				for(int col=1;col<=(3* totalRows - row - 1);col++){
					if( col >= ( row -  totalRows + 1 )  ) {
						System.out.print("* ");  
					}else {
						System.out.print("  ");  
					}
				}//inner for-loop_2
			}		
			System.out.println();// Move cursor to next row.
		}// outer for-loop
	}
}
