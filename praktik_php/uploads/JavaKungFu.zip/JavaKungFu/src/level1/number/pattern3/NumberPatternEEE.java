package level1.number.pattern3;

public class NumberPatternEEE {

	public static void main(String[] args) {
		
		int totalRows = 5;  //number of rows to display
		int num;
		String numStr;
		String spaces = "  ";	// 2 spaces
		
		// Row level Repetitive Action : 
		for( int row = 1 ; row <= totalRows ; row ++ ) {	 
		num = 2*row - 1;

			// Column level Repetitive Action : 
			for( int col = 1 ; col <= ( 2* totalRows  - 1 ) ; col++ ) {

				// calculates position to print numeric character 
				if( col >= ( (totalRows - row) + 1 ) && 
				    col <= (  (  totalRows + row )  - 1 ) ) {
					if(col < totalRows ) {
						numStr = num  + " ";
						System.out.print( numStr );  
						num = num - 1;
					}else if(col >=totalRows) {
						numStr = num  + " ";
						System.out.print( numStr ); 
						num = num +1;
					}
				}else {
					System.out.print(spaces);// print spaces
				}
			}// inner loop	
			
			// Move to next row
			System.out.println();

		}// outer loop 

	}

}
