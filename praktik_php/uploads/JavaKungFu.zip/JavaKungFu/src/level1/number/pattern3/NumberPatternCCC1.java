package level1.number.pattern3;

public class NumberPatternCCC1 {

	public static void main(String[] args) {

		int totalRows = 5;  //number of rows to display
		String colStr;
		String spaces = "  ";//2 spaces

		// Row level Repetitive Action : 
		for( int row = totalRows ; row >= 1 ; row -- ) {
			// Column level Repetitive Action : 
			// 1)Move cursor in the same row. 2)print character 
			for( int col = row ; col <= ( 2*row - 1 )   ; col++) {
				 colStr = col  + " ";
				 System.out.print( colStr ); 
				 
			}// inner loop
			
			System.out.println();// Move cursor to the next row
		}// outer loop 
	}

}
