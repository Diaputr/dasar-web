package recursive;

public class ForLoopIncrement3 {

	public static void main(String[] args) {
		
		loopInc(1 ,15);
		
	}
	
	static void loopInc( int counter ,int totalRows) {
		
		if(counter <= totalRows ) {
			System.out.println(counter);//print to console
			loopInc( counter + 1 ,totalRows);
		}
		
	}
}
