package level1.star;
public class PatternH1_1 {
	public static void main(String[] args) {
		int totalRows = 7;// number of rows to display
		int count = -1;// counter to increment/decrement .
		
		// Row level Repetitive Action : 
		// Action1.Execute's Column level Repetitive Action 
		// Action2.Move cursor to next row.
		for (int row = 1; row <= (2 * totalRows - 1); row++) {
			// increment count when row value is <= than the total number of rows 
			// else decrease count by value 1.
			if (row <= totalRows) {
				count = count + 1;
			} else {
				count = count - 1;
			}
			
			// Column level Repetitive Action : 

			// Action1.Move cursor in the same row
			// Action2.prints star �* � character 
			for (int col = 1; col <= ( totalRows + count ) ; col++) {
				if( col >= ( totalRows - count ) ) {
					System.out.print("* ");
				}else {
					System.out.print("  ");
				}
				
			}// inner for-loop
			System.out.println();// Move cursor to next row.
		}// outer for-loop
	}
}
