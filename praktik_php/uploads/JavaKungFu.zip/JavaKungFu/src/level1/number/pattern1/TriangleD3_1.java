package level1.number.pattern1;

public class TriangleD3_1 {

	public static void main(String[] args) {
		
		int  totalRows = 5;  //number of rows to display

		for( int row = totalRows ; row >=1  ; row -- ) {

			System.out.println();// move control to the next line 

			for(int col = totalRows; col >= 1    ; col--) {
				
				if( col <=  row ) {
					// row value to be printed 
					System.out.print( row + " " );  
				}else {
					// spaces to be printed 
					System.out.print( "  " );  
				}

			}
		}
	}
}
