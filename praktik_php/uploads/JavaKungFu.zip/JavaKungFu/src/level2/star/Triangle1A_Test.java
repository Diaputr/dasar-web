package level2.star;
public class Triangle1A_Test
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 10;  //number of rows to display
        
		//works like  all columns are bundled into one row.This row gets updated and printed at particular row number.
		StringBuilder rowBuilder = new StringBuilder(totalRows);
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			rowBuilder.append("*");  
			System.out.println(rowBuilder.toString());

		}
	}
}
