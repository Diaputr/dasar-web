package level1.star;


public class Triangle2G_2 {

	public static void main(String[] args) {

		int  totalRows = 5;  
		int counter = 0;
		//number of rows to display
		for( int row = 1 ; row <= ( 2* totalRows - 1 ) ; row ++ ) {

			if(  row <= totalRows ) {
				counter = counter +1;
			}					

			if( row >totalRows ) {
				counter = counter - 1;
			}		
			System.out.println();
			for(int col = 1 ; col <= counter   ; col++) {
				System.out.print("* ");  
			}

		}

	}

}
