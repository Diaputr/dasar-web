package strings;

public class StringCharPattern {

	public static void main(String[] args) {
		
		String str = "Programming";
		int index ;
		String spaces = "";
		
		for( index = 0 ; index < str.length() ; index++) {
			spaces = spaces.concat("_");
			String  print  = String.valueOf(str.charAt(index) ) ;
			print  = print  + spaces + "|"+ spaces ;
			print  = print + str.charAt(index);
			System.out.println( print );
		}
		
	}

}
