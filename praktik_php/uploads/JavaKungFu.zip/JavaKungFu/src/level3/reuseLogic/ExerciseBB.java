package level3.reuseLogic;

import level1.star.TriangleB;
import level1.star.TriangleC;
import level1.star.TriangleD;


public class ExerciseBB {

	public static void main(String[] args) {
		int totalRows = 10;
		
		TriangleB.draw(totalRows);
		TriangleC.draw(totalRows, totalRows - 1);

	}

}
