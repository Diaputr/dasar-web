package basics;
public class VerifyAlphabetM{
	public static void main(String[] args) {
		int row,col;
		int TOTAL_ROWS = 7;
		int TOTAL_COLUMNS = 5;
		boolean condition; //logical condition variable
		// A space characters are used to show the formatted output.
		String  dataSpaces = " ";
		String  blankSpaces = "  " ;
		for( row = 1 ; row <= TOTAL_ROWS ; row ++ ) {
			for( col = 1 ; col <= TOTAL_COLUMNS ; col ++ ) {
				condition = (col==1)||(col==5)|| 
							( ( (row==col)|| (row+col ==6) ) && row<=3 ) ;
				if( condition ) {
					System.out.print(  "*"  + dataSpaces );
				}else {
				// 4 space characters 
					System.out.print( blankSpaces );
				}
			}
			// since control moves to the next line due to <br/>
			// printing starts at the next line
			System.out.println();// Move cursor to the next row
		}

	}
}
