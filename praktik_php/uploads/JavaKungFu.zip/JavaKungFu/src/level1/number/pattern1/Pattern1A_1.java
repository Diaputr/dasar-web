package level1.number.pattern1;

public class Pattern1A_1 {

	public static void main(String[] args) {

		System.out.print("*"); // print 1 time
		System.out.println(); // Move cursor to the next row

		System.out.print("*");
		System.out.print("*");//print 2 times, same row
		System.out.println();// Move cursor to the next row

		System.out.print("*");
		System.out.print("*");
		System.out.print("*");// print 3 times, same row
		System.out.println();// Move cursor to the next row

		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");//print 4 times, same row
		System.out.println();// Move cursor to the next row

		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");//print 5 times, same row
		System.out.println();// Move cursor to the next row
	}
}
