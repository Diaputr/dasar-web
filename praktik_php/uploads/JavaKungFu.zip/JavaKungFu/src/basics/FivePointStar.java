package basics;
public class FivePointStar{
	public static void main(String[] args) {
		int row,col;
		int TOTAL_ROWS = 23;
		int TOTAL_COLUMNS = 22;
		boolean condition; //logical condition variable
		// &nbsp: A space character is used to show formatted output.
		String  dataSpaces = ",";
		String  blankSpaces = " ," ;
		int  x = 12;
		int y = 12;
		int out1 = 0;
		int out2 = TOTAL_COLUMNS + 2;
		for( row = 1 ; row <= TOTAL_ROWS ; row ++ ) {
			if( row >=8  && row <=15) {
				out1 = out1 + 1;
				out2 = out2 - 1;
			}else if(row  > 15) {
				out1 = out1 - 1;
				out2 = out2 + 1;
			}
			if( row >= 17) {
				x = x - 2;
				y = y + 2 ;
			}
			for( col = 1 ; col <= TOTAL_COLUMNS ; col ++ ) {

				if( row >= 8) {
					
					if( col== out1 || col== out2 ) {
		
						//System.out.println(  " val "  +out1 + ":" +  dataSpaces );
						System.out.print(  "*"  +  dataSpaces );
					}
				}
				
				if( row >= 16) {
					
					if( col==x || col==y  ) {
		
						//System.out.println(  " val "  +x + ","+ y+ ":" +  dataSpaces );
						System.out.print(  "*"  +  dataSpaces );
					}
				}
				condition = ( row == 8);
				if( condition ) {
					System.out.print(  "*"  + dataSpaces );
				}else {
				// 4 space characters 
					System.out.print( blankSpaces );
				}
		}
			// since control moves to the next line due to <br/>
			// printing starts at the next line
			System.out.println();// Move cursor to the next row
		}

	}
}
