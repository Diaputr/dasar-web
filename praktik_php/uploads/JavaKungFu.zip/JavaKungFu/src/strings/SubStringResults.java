package strings;

public class SubStringResults {

	public static void main(String[] args) {
		
		String str = "Programming";
		int index ;
		String subStr = "";
		int LENGTH = str.length();
		System.out.println( "Length of String  = " + LENGTH);
		System.out.println( "===================");
		for( index = 0 ; index <= LENGTH ; index++) {
			subStr = str.substring(0, index);
			System.out.println("str.substring( 0, " +  index + ") = " + subStr);
		}
		index = LENGTH - 1;
		subStr = str.substring(5, index);
		System.out.println("str.substring( 5, " +  index + ") = " + subStr);
		System.out.println( "===================");
		System.out.println("Please notice first and last substring() method results.");
	}

}
