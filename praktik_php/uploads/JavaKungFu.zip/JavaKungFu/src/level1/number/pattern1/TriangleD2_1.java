package level1.number.pattern1;

public class TriangleD2_1 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display

		for( int row = totalRows ; row >=1  ; row -- ) {

			System.out.println();// move control to the next line 

			for(int col = 1; col <= ( totalRows  )    ; col++) {
				if( col <= ( totalRows - row ) ) {
					// spaces to be printed 
					System.out.print( "  " );  
				}else {
					// row value to be printed 
					System.out.print( row + " " );  
				}

			}
		}
	}
}
