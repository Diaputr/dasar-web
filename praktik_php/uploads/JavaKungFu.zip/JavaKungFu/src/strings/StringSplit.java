package strings;

public class StringSplit {

	public static void main(String[] args) {
		String str = "Programming";
		String strSplit[] = str.split("r");
		System.out.println( strSplit[0]);
		System.out.println( strSplit[1]);
		System.out.println( strSplit[2]);
	}

}
