package level1.number.pattern3;

public class TriangleB2_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 10;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {

			System.out.println();// move control to the next line where new set of characters will get printed.
			int num = 2*row - 1;//  horizontally   (2*row - 1 >= num >=row)
			
			// spaces to be printed before printing numbers
			for(int col = 1 ; col <= (totalRows)   ; col++) {
				if( col <= (totalRows - row) ) {
					if( col  < 10) {
						System.out.print( "   " );  //3 spaces for 1 digit number
					}else {
						System.out.print( " " );  //1 spaces for 2 digit number
					}
					
				}else if( num >= row ) {
					if( num  < 10) {
						System.out.print( "  " + num  );  //2 spaces for 1 digit number
					}else {
						System.out.print( " " + num);  //1 spaces for 2 digit number
					}
					num = num - 1;
				}
				
			}
		}
	}
}
