package level1.star;
public class PatternC2{
	public static void main(String[] args) {
		int  totalRows = 5;  //number of rows to display

		// Row level Repetitive Action : 
		// Action1.Execute's Column level Repetitive Action 
		// Action2.Move cursor to next row.
		for( int row = 1 ; row <= totalRows ; row ++ ) {
	 		// Column level Repetitive Action : 
			
			// Action1.Move cursor in the same row
			for(int col = 1 ; col <= totalRows  ; col++) {
		
				if( col <= ( totalRows - row ) ) {
					// Action2.prints space � � character 
					System.out.print("  ");  
				}else {
					// Action3.prints star �* � character 
					System.out.print("* ");  
				}
			}
			System.out.println();// Move cursor to the next row

		}
	}
}
