public class NestedForLoop3 {

	public static void main(String[] args) {

		for ( int counter = 5 ; counter >= 1; counter -- ){
			// print the variable counter�s value	
			System.out.println( counter );  //statement1
			System.out.println( 2*counter );//statement2
			System.out.println( 3*counter );//statement3

		}
	}

}

