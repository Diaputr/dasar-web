package level1.number.pattern2;

public class NumberPatternBB {

	public static void main(String[] args) {

		int totalRows = 5; // number of rows to display

		for ( int row = 1; row <= totalRows; row++ ) {

			System.out.println();// move control to the next line

			// spaces to be printed before printing numbers
			for ( int col = 1; col <= (totalRows - row); col++ ) {
				System.out.print("  ");
			}

			for ( int num = row; num >= 1; num-- ) {
				// added extra space for clarity in output.
				String numStr = num + " ";
				System.out.print(numStr);
			}
		}
	}
}
