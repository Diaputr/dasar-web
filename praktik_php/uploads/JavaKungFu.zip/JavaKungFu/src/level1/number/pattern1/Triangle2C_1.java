package level1.number.pattern1;

public class Triangle2C_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 5;  //number of rows to display

		for( int row = totalRows ; row >= 1 ; row -- ) {

			System.out.println();// move control to the next line 

			// row value to be printed
			for(int col = 1 ; col <= row    ; col++) {
					System.out.print( row + " " );  
			}
		}
	}
}
