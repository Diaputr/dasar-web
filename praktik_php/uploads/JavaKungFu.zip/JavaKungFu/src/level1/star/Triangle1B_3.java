package level1.star;

public class Triangle1B_3 {

	public static void main(String[] args) {
		int  totalRows = 5;  //number of rows to display
		
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			if( row == 1) {
				System.out.println();
				
				for( int col = 1; col <= totalRows  ; col ++) {
					
					if( col <= ( totalRows - row )  ) { 
						System.out.print( "  ");
					}else{
						System.out.print( " *");
					}
				}

			}
			
			if( row == 2) {
				System.out.println();
				for( int col = 1; col <= totalRows ; col ++) {
					
					if( col <= ( totalRows - row )  ) { 
						System.out.print( "  ");
					}else {
						System.out.print( " *");
					}
				}
			}
			
			if( row == 3 ) {
				System.out.println();
				for( int col = 1; col <= totalRows ; col ++) {
					
					if( col <= ( totalRows - row )  ) { 
						System.out.print( "  ");
					}else{
						System.out.print( " *");
					}
				}
			}			
			
			if( row == 4 ) {
				System.out.println();
				for( int col = 1; col <= totalRows ; col ++) {
					
					if( col <= ( totalRows - row )  ) { 
						System.out.print( "  ");
					}else {
						System.out.print( " *");
					}
				}
			}			
			
			if( row == 5 ) {
				System.out.println();
				for( int col = 1 ; col <= totalRows; col ++) {
					
					if( col <= ( totalRows - row )  ) { 
						System.out.print( "  ");
					}else {
						System.out.print( " *");
					}
				}
			}						
		}
	}

}
