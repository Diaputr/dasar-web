package level2.star;


public class Triangle1D1_Test {

	public static void main(String[] args) {

		int  totalRows = 10;  //number of rows to display

		//fill stars of size=totalRows,as star characters goes on decreases.
		StringBuilder rowBuilder = new StringBuilder();
		for(int count = 1 ; count <= totalRows + 1; count ++ ) {
			rowBuilder.append("*");
		}
		int col = 1;
		for( int row = 1 ; row <= totalRows +1  ; row ++ ) {

			System.out.println();// move control to the next line where new set of characters will get printed horizontally.

			if( col >= row && col <=totalRows ) {
				rowBuilder.setCharAt((col -1),' ');  
				System.out.println(rowBuilder.toString());

			}
				col++;
		}
	}
}
