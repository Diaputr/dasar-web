package level3.arrays;

public class SingleArrayOrderedSort3 {
	
		static void bubbleSort( int[] arr ) {
			int current = 0;
			int next =  current + 1;
			int temp = 0;
		
	
			for ( int i = 0; i <  arr.length; i ++ ) {
				
				if(  current < next && next < arr.length) {
					for(int val : arr) {
						System.out.print(val + " ," );
					}
					System.out.println();
					//order is to maintained 
					if(arr[current] !=0  ) {
						current = current + 1;
						next = next + 1;
						continue;
					}
					
//					if(arr[current] !=0 && arr[next] ==0 ) {
//						current = current + 1;
//						next = next + 1;
//						continue;
//					}
					if(arr[current] ==0  ) {
						
						if( arr[next] !=0 ) {
							temp = arr[next];
							arr[next] = arr[current];
							arr[current] = temp;
							current = current + 1;
						}
						next = next + 1;
						
					}
					
				}else {
					break;
				}


				}
			
		}
	   public static void main(String[] args) {
		   int arr[] = {1, 9, 8, 4, 0, 0, 2, 7, 0, 6, 0, 9}; 
	      System.out.println("Single array Ordered sort");

	      for(int i = 0; i < arr.length; i++) {
	         System.out.print(arr[i] + " ");
	      }
	      System.out.println();
	      bubbleSort(arr);
	      System.out.println("Single array Ordered sort");

	      for(int i = 0; i < arr.length; i++) {
	         System.out.print(arr[i] + " ");
	      }
	   }

}
