package level3.reuseLogic;

import level1.star.TriangleD;
import level1.star.TriangleH;
import level1.star.TriangleB;


public class ExerciseHH {

	public static void main(String[] args) {
		int totalRows = 10;
		
		TriangleH triH = new TriangleH();
		
		// StringBuilder style of Class
		triH.setCharsForDesign("  ")  // 2 spaces
		      .setCharsNotForDesign("* "); // 1 start 1& 1 space
		triH.draw(totalRows);

	}

}
