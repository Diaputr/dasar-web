package level3.reuseLogic;

import level1.star.TriangleA;
import level1.star.TriangleC;

public class TriangleG {

	public static void main(String[] args) {
		
		int totalRows = 10;
		
		TriangleA.draw(totalRows);
		TriangleC.draw(totalRows - 1);

	}

}
