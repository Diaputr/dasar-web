package level1.star;


public class TriangleD {

	public static void main(String[] args) {

		int  totalRows = 15;  //number of rows to display

		draw(totalRows);

	}

	/**
	 * @param totalRows
	 */
	public static void draw(int totalRows) {
		for( int row = 1 ; row <= totalRows ; row ++ ) {

			for(int col = 1 ; col <= totalRows  ; col++) {
				if( col >= row && col <=totalRows ) {
					System.out.print("* ");  
				}else {
					System.out.print("  ");
				}
			}//inner loop
			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
		}//outer loop
	}

	public static void draw(int totalRows,int shiftColums) { 
		
		StringBuffer  sb = new StringBuffer();
		for(int shift = 1 ; shift <= shiftColums ; shift++) {
			sb.append("  ");
		}
		
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			System.out.print(sb.toString()); //prefix blank spaces for every row
			for(int col = 1 ; col <= totalRows  ; col++) {
				if( col >= row && col <=totalRows ) {
					System.out.print("* ");  
				}else {
					System.out.print("  ");
				}
			}//inner loop
			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
		}//outer loop
	}
}
