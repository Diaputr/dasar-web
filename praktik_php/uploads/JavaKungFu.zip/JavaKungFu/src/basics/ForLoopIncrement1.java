package basics;

public class ForLoopIncrement1 {

	public static void main(String[] args) {
		
		for ( int counter = 0 ; counter <10 ; counter ++ ){
			System.out.println(counter );//print to console
		}
		
	}
}
