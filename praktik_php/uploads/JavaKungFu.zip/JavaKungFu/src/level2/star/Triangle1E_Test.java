package level2.star;


public class Triangle1E_Test {

	public static void main(String[] args) {

		int  totalRows = 15;  //number of rows to display

		//fill spaces of size=totalRows,as space characters goes on decreases.
		StringBuilder rowBuilder = new StringBuilder();
		for(int count = 1 ; count <= ( 2* totalRows ) ; count ++ ) {
			rowBuilder.append("  ");
		}
		
		for( int row = 1 ; row <= totalRows ; row ++ ) {

			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
			
			// repetition happens 2* totalRows  - 1 times horizontally   (1 <=Col <=9)
			// since rowBuilder starts it index = 0 ,so -1 in first parameter
			String column = rowBuilder.substring( 2* ( (totalRows - row) + 1 - 1), 2*( (  totalRows + row )  - 1) );
			column = column.replace("  ", " *");

			rowBuilder.replace(  2* ( (totalRows - row) + 1 - 1), 2*( (  totalRows + row )  - 1)  ,column);  
			System.out.println(rowBuilder.toString());

		}//end  outer for - loop 

	}

}
