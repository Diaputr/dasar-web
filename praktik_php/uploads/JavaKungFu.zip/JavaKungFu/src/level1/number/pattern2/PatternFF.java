package level1.number.pattern2;


public class PatternFF {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display
		int ul_numDec = 0;
		for( int row = 0 ; row < totalRows ; row ++ ) {
			
			for(int numInc = 1 ; numInc <= ( totalRows - row ) ; numInc++) {
				System.out.print( numInc + " ");
			}
			for(int space = 1 ; space <= ( 2*row  - 1) ; space++) {
				System.out.print( "  ");
			}
			
		    if(row == 0 ){
		    	ul_numDec =  ( totalRows - 1);
		      }else{
		    	  ul_numDec  = ( totalRows - row ) ;
		     }

			for(int numDec = ul_numDec ; numDec >= 1; numDec--) {
				System.out.print( numDec + " ");
			}
			System.out.println();// move control to the next line
			
	   }
	}
}
