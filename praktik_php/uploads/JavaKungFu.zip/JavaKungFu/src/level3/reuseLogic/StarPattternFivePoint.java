package level3.reuseLogic;

import level1.star.TriangleB;
import level1.star.TriangleE;
import level1.star.TriangleF;
import level1.star.TriangleA;

//TODO :  Not done.Using constructors to reverse the printing & non-printing chars.
public class StarPattternFivePoint {

	public static void main(String[] args) {
		int totalRows = 5;
		int align = 2;
		
		TriangleE  triE1 = new TriangleE("* " , "  ");
		triE1.draw(totalRows + align, 2 * totalRows);
		
		TriangleF  triF1 = new TriangleF("* " , "  ");
		triF1.drawBottomCut( 3 * totalRows + align ,2* totalRows + align );
		
		triE1 = new TriangleE("* " , "  ");
		triE1.drawTopCut( 3 * totalRows + align, 2* totalRows + align );
		
		triF1.draw(totalRows + align , 2 * totalRows);

	}

}
