package level3.reuseLogic;

import level1.star.TriangleB;
import level1.star.TriangleE;
import level1.star.TriangleF;
import level1.star.TriangleA;

//TODO :  Not done.Using constructors to reverse the printing & non-printing chars.
public class ExerciseFF {

	public static void main(String[] args) {
		int totalRows = 10;
		
		//reversing the design
		TriangleF  triE1 = new TriangleF( "  " , "* ");
		triE1.draw(totalRows);


	}

}
