package level1.number.pattern3;


public class TriangleE1_Test {

	public static void main(String[] args) {

		int  totalRows = 7;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
			//repetition happens 2* totalRows  - 1 times horizontally   (1 <=Col <=9)
			int num = ( 2* row  - 1 );
			for(int col = 1 ; col <= ( 2* totalRows  - 1 ) ; col++) {
				//printing numbers at the calculated position 
				if( col >= ( (totalRows - row) + 1 )    && col <= (  (  totalRows + row )  - 1 )   ) {
					if(col < totalRows ) {
						System.out.print(num+" ");  
						num = num -1;
					}else if(col >=totalRows) {
						System.out.print(num+" ");  
						num = num +1;
					}
				
				}else {
					System.out.print("  ");
				}
			}//end  inner for - loop 
		}
	}

}
