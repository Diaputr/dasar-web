package strings;

public class StringPatternA1 {

	public static void main( String[] args ) {

		int totalRows = 5;  // number of rows to display
		String line = "";	// intialize with blank string.

		for( int row = 1 ; row <= totalRows ; row ++ ) {

			// Column level Repetitive Action : 
			// a space is added for clarity in the output
			line = line.concat("*" + " " );

			System.out.print(line); 

			// Move cursor to the next row
			System.out.println();
		}
	}

}
