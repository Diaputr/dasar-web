package level1.star;


public class Triangle1D_3 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {

			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
			
			for(int col = 1 ; col <= totalRows  ; col++) {
				if( col >= row && col <=totalRows ) {
					System.out.print("* ");  
				}else {
					System.out.print("  ");
				}
			}

		}

	}

}
