package level1.number.pattern2;


public class ProblemGBEE2 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
			//repetition happens 2* totalRows  - 1 times horizontally   (1 <=Col <=9)
			int num = row;
			for(int col = 1 ; col <= ( 2* totalRows  - 1 ) ; col++) {
				
				if( col >= ( (totalRows - row) + 1 )    && col <= (  (  totalRows + row )  - 1 )   ) {
					if(col < totalRows ) {
						System.out.print(row+" ");  
						num = num -1;
					}else if(col >=totalRows) {
						System.out.print(row+" ");  
						//num = num +1;
					}
				
				}else {
					System.out.print("  ");
				}
			}//end  inner for - loop 
		}
	}

}
