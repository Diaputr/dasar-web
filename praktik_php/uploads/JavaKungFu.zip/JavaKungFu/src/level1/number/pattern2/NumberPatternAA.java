package level1.number.pattern2;

public class NumberPatternAA {

	public static void main(String[] args) {

		int  totalRows = 10;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			System.out.println();// move control to the next line 
			
			for(int col = 1 ; col <= row  ; col++) {
				// added extra space for clarity in output.
				String num = col + " ";
				System.out.print( num );  
			}

		}
	}
}
