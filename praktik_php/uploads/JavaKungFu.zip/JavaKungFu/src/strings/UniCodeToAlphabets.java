package strings;

public class UniCodeToAlphabets {

	public static void main( String[] args ) {

		String spaces = "  ";
		System.out.println("Alphabets and it's equivalent unicode." );
		System.out.println("--------------------------------------" );
		for ( int cnt = 0; cnt < 26; cnt++ ) {
			int unicodeCap = (65 + cnt);
			int unicodeSmall = (97 + cnt);
			String capLetter = (char) unicodeCap + "=" + (unicodeCap);
			String smallLetter = (char) unicodeSmall + "=" + (unicodeSmall);
			String print = capLetter + spaces + "|" + spaces + smallLetter ;
			System.out.println(print);
		}
	}

}
