package level3.reuseLogic;

import level1.star.TriangleB;
import level1.star.TriangleE;
import level1.star.TriangleF;
import level1.star.TriangleA;

//TODO :  Not done.Using constructors to reverse the printing & non-printing chars.
public class ExerciseMM {

	public static void main(String[] args) {
		int totalRows = 5;
		
		TriangleE  triE1 = new TriangleE("*" , "  ");
		triE1.draw(totalRows + 2,2 * totalRows);
		
		TriangleF  triF1 = new TriangleF("*" , "  ");
		triF1.drawBottomCut( 3 * totalRows + 2,2* totalRows +2);
		
		triE1 = new TriangleE("*" , "  ");
		triE1.drawTopCut( 3 * totalRows + 2 ,2* totalRows +2 );
		
		TriangleF triF2 = new TriangleF("*" , "  ");
		triF2.draw(totalRows + 2, 2 * totalRows);

	}

}
