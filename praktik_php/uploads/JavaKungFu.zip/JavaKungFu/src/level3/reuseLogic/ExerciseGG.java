package level3.reuseLogic;

import level1.star.TriangleB;
import level1.star.TriangleD;


public class ExerciseGG {

	public static void main(String[] args) {
		int totalRows = 10;
		
		TriangleB.draw(totalRows);
		TriangleD.draw(totalRows -1,1); // draw 9 rows leaving the biggest one and shift 1 column right.

	}

}
