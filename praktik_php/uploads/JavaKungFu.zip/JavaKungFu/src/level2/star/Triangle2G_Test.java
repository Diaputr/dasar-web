package level2.star;


public class Triangle2G_Test {

	public static void main(String[] args) {

		int  totalRows = 10;  
		int counter = 0;
		//number of rows to display
		StringBuilder rowBuilder = new StringBuilder();
		for(int count = 1 ; count <= totalRows; count ++ ) {
			rowBuilder.append("  ");
		}
		for( int row = 1 ; row <= ( 2* totalRows - 1 ) ; row ++ ) {

			if(  row <= totalRows ) {
				rowBuilder.setCharAt(2*counter,'*');
				counter = counter +1;
			}else {
				counter = counter - 1;
				rowBuilder.setCharAt(2*counter,' ');
				
			}
			
			System.out.println(rowBuilder.toString());// move control to the next line where new set of characters will get printed.
		

		}

	}

}
