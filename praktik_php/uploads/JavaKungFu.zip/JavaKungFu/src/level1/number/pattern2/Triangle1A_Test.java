package level1.number.pattern2;

public class Triangle1A_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 10;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			System.out.println();// move control to the next line where new set of characters will get printed.
			
			//repetition happens row number times horizontally   (1 <=Col <=row)
			
			for(int col = 1 ; col <= row  ; col++) {
				String num = col + " ";// added extra space for clarity in output.
				System.out.print( num );  
			}

		}
	}
}
