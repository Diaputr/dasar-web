package level1.star;


public class Triangle1G_1 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display

		for( int row = 1 ; row <= 9 ; row ++ ) {

			if(  row <= totalRows ) {
				System.out.println();
				//repetition happens 5 times horizontally   (1 <=Col <=5)
				for(int col = 1 ; col <= row  ; col++) {
					System.out.print("* ");  
				}
			}					

			if( row == 6) {
				System.out.println();
				//repetition happens 4 times horizontally   (1 <=Col <=4)
				for(int col = 1 ; col <= 4  ; col++) {
					System.out.print("* ");  
				}
			}		

			if( row == 7) {
				System.out.println();
				//repetition happens 3 times horizontally   (1 <=Col <=3)
				for(int col = 1 ; col <= 3  ; col++) {
					System.out.print("* ");  
					
				}
			}	

			if( row == 8) {
				System.out.println();
				//repetition happens 2 times horizontally   (1 <=Col <=2)
				for(int col = 1 ; col <= 2  ; col++) {
					System.out.print("* ");  
					
				}

			}

			if( row == 9) {
				System.out.println();
				// 1 time   (1 <=Col <=1)
				for(int col = 1 ; col <= 1  ; col++) {
					System.out.print("* ");  
		
				}
			}
		}

	}

}
