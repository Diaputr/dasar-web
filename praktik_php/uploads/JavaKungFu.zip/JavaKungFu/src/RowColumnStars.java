
public class RowColumnStars {

	public static void main(String[] args) {
		int TOTAL_ROWS = 10;
		int TOTAL_COLUMNS = 10;

		for( int row = 1 ; row <= TOTAL_ROWS ; row ++ ) {
			for( int col = 1 ; col <= TOTAL_COLUMNS ; col ++ ) {
				System.out.print("* " );
			}
			// moves the control to the next line and 
			// prints next row iteration value 
			System.out.println();
			
		}
	}

}
