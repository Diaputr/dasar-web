package level1.number.pattern3;

public class NumberPatternDDD2 {

	public static void main(String[] args) {

		int totalRows = 5; // number of rows to display
		int num;
		String numStr;
		String spaces = "  "; // 2 spaces

		// Row level Repetitive Action :
		for (int row = totalRows; row >= 1; row--) {
			num = 2 * row - 1;
			// Column level Repetitive Action :
			for (int col = 1; col <= (totalRows); col++) {
				
				// when spaces are to be printed
				if (col <= (totalRows - row)) {
					System.out.print(spaces);
				} else {
					numStr = num + " ";
					System.out.print(numStr);
					num--;
				}
			} // inner loop
			
			// Move cursor to the next row
			System.out.println();
			
		} // outer loop
	}

}
