package basics;

public class ForLoopIncrement2 {

	public static void main(String[] args) {
		
		for ( int counter = 0 ; counter <10 ; counter ++ ){
			int  result = counter + 1; //add 1 to the counter
			System.out.println( result);//print to console
		}
		
	}
}
