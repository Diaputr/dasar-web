package level3.reuseLogic;

import level1.star.TriangleE;
import level1.star.TriangleF;

public class ExerciseJJ {

	public static void main(String[] args) {
			int totalRows = 5;
			
			//reversing the design
			TriangleE  triE1 = new TriangleE("* " , "  ");
			triE1.draw(totalRows,totalRows);
			
			TriangleF  triF1 = new TriangleF("* " , "  ");
			triF1.drawBottomCut( 2 * totalRows , totalRows + 1);
			
//			triE1 = new TriangleE("* " , "  ");
//			triE1.draw( 2 * totalRows );
//			
//			triF1.draw(totalRows,totalRows);

		}


}
