package level1.number.pattern2;

public class NumberPatternCC2 {

	public static void main(String[] args) {
		
		int  totalRows = 5;  //number of rows to display
		
		// Row level Repetitive Action : 
		for( int row = 1 ; row <= totalRows ; row ++ ) {

			// Column level Repetitive Action : 
			// Action1.Move cursor in the same row
			// Action2.print character 	
			
			// spaces to be printed before printing numbers
			for(int col = 1 ; col <= totalRows    ; col++) {
				
				if( col <= (totalRows + 1 - row) ) {
					System.out.print( col + " " );  
				}else {
					System.out.print( "  " );  
				}
			}
			
			// move control to the next line 
			System.out.println();
		}
	}
}
