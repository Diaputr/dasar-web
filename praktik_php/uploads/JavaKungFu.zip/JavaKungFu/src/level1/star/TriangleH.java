package level1.star;

/**
 * 
 *  Initialization using builder design pattern
 *
 */
public class TriangleH {

	// default value
	private  String charsForDesign; 
	private  String charsNotForDesign;
	
	
	public String getCharsForDesign() {
		return charsForDesign;
	}


	public TriangleH setCharsForDesign(String charsForDesign) {
		this.charsForDesign = charsForDesign;
		return this;
	}


	public String getCharsNotForDesign() {
		return charsNotForDesign;
	}


	public TriangleH setCharsNotForDesign(String charsNotForDesign) {
		this.charsNotForDesign = charsNotForDesign;
		return this;
	}


	/**
	 * @param totalRows
	 */
	public  void draw(int totalRows) {
		// initialize with first * to display at the colMin/ colMax position.
		int colMin = totalRows;  //
		int colMax = totalRows;  // 
		//number of rows to display
		for( int row = 1 ; row <= ( 2* totalRows - 1 ) ; row ++ ) {

			if(  row <= totalRows ) {
				
				System.out.println();
				for(int col = 1 ; col <= ( 2* totalRows - 1 )  ; col++) {
					if( col >= colMin &&  col <= colMax) {
						System.out.print( getCharsForDesign() );  
					}else {
						System.out.print( getCharsNotForDesign() );  
					}
				}
				//as not to repeat row =5 output twice ,since calculating colMin & colMax before display of * in a row
				if( row <  totalRows) {
					colMax = colMax +  1 ; // increase column value
					colMin = colMin -  1 ;// decrease column value
				}
			}					

			if( row >totalRows ) {
				colMax = colMax -  1 ; // decrease column value
				colMin = colMin +  1 ;// increase column value
				System.out.println();
				for(int col = 1 ; col <= ( 2* totalRows - 1 )   ; col++) {
					if( col >= colMin &&  col <= colMax) {
						System.out.print( getCharsForDesign() );  
					}else {
						System.out.print( getCharsNotForDesign() );  
					};  
				}

			}		

		}
	}
	
	public static void main( String[] arg ) {
		int totalRows = 10;
		TriangleH triH = new TriangleH();
		
		// StringBuilder style of Class
		triH.setCharsForDesign("* ") // 1 start 1& 1 space
		      .setCharsNotForDesign("  ");  // 2 spaces
		triH.draw(totalRows);
	}

}
