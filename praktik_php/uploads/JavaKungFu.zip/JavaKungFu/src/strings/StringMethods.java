package strings;

public class StringMethods {

	public static void main(String[] args) {

		String str = "immpossible";
		System.out.println("Given String : " + str );
		System.out.println("str.replace(\"imm\", \"i am \") "  );
		 str = str.replace("imm", "i am ");
		 System.out.println("Updated String : " + str );
		 for ( int index = 0 ; index < str.length() ; index ++) {
			 System.out.println(  index + " : " + str.charAt(index) );
		 }
		 System.out.println("-------------------------------------------------------------");
		 
		 System.out.println("str.indexOf(\"i\") : " + str.indexOf("i") );
		 System.out.println("str.lastIndexOf(\"i\") : " + str.lastIndexOf("i"));
	}

}
