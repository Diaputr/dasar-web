package level1.number.pattern1;

public class Triangle1C_1 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {

			System.out.println();// move control to the next line 
			// numbers to be printed before printing spaces
			for(int col = 1 ; col <= totalRows    ; col++) {
				int upper_limit = ( totalRows + 1 - row );
				if( col >= 1 &&  col <= upper_limit  ) {
					System.out.print( upper_limit + " " );  
				}else {
					System.out.print( "  " );  
				}
			}//inner loop
			
		}// outer loop
	}
}
