package level1.star;


public class TriangleF {

	// default value
	private  String charsForDesign = "* "; 
	private  String charsNotForDesign = "  ";
	
	
	public TriangleF( String charsForDesign, String charsNotForDesign ) {
		super();
		this.charsForDesign = charsForDesign;
		this.charsNotForDesign = charsNotForDesign;
	}

	public TriangleF() {
		
	}

	public static void main(String[] args) {

		int  totalRows = 10;  //number of rows to display

		TriangleF  triF = new TriangleF();
		triF.draw(totalRows);

	}
	
	/**
	 * @param totalRows
	 */
	public  void draw(int totalRows ) {
		drawBottomCut( totalRows ,0);
	}

	/**
	 * @param totalRows
	 */
	public  void drawBottomCut(int totalRows ,int skipRows) {
		for( int row = 1 ; row <= totalRows - skipRows; row ++ ) {

			//repetition happens 2 * totalRows  - 1 times horizontally  
			for(int col = 1 ; col <= ( 2 * totalRows  - 1 )   ; col++) {
				if( col >= row    && col <= ( 2 * totalRows   - row ) ) {
					System.out.print(charsForDesign);  
				}else {
					System.out.print(charsNotForDesign);
				}
			} //inner loop
			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
		}//outer loop
	}
	public  void draw(int totalRows ,int shiftColumns) {
		
		StringBuffer  sb = new StringBuffer();
		for(int shift = 1 ; shift <= shiftColumns ; shift++) {
			sb.append("  ");
		}
		for( int row = 1 ; row <= totalRows ; row ++ ) {

			System.out.print(sb.toString());
			//repetition happens 2 * totalRows  - 1 times horizontally  
			for(int col = 1 ; col <= ( 2 * totalRows  - 1 )   ; col++) {
				if( col >= row    && col <= ( 2 * totalRows   - row ) ) {
					System.out.print(charsForDesign);  
				}else {
					System.out.print(charsNotForDesign);
				}
			} //inner loop
			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
		}//outer loop
	}
}
