package level1.star;


public class Triangle2H_1 {

	public static void main(String[] args) {

		int  totalRows = 5;  
		
		// initialize with first * to display at the colMin/ colMax position.
		int colMin = totalRows;  //
		int colMax = totalRows;  // 
		//number of rows to display
		for( int row = 1 ; row <= ( 2* totalRows - 1 ) ; row ++ ) {

			if(  row <= totalRows ) {
				
				System.out.println();
				for(int col = 1 ; col <= ( 2* totalRows - 1 )  ; col++) {
					if( col >= colMin &&  col <= colMax) {
						System.out.print("* ");  
					}else {
						System.out.print("  ");  
					}
				}
				//as not to repeat row =5 output twice ,since calculating colMin & colMax before display of * in a row
				if( row <  totalRows) {
					colMax = colMax +  1 ; // increase column value
					colMin = colMin -  1 ;// decrease column value
				}
			}					

			if( row >totalRows ) {
				colMax = colMax -  1 ; // decrease column value
				colMin = colMin +  1 ;// increase column value
				System.out.println();
				for(int col = 1 ; col <= ( 2* totalRows - 1 )   ; col++) {
					if( col >= colMin &&  col <= colMax) {
						System.out.print("* ");  
					}else {
						System.out.print("  ");  
					};  
				}

			}		

		}

	}

}
