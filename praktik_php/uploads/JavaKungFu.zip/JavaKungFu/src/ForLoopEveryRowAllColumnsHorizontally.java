
public class ForLoopEveryRowAllColumnsHorizontally {

	public static void main(String[] args) {
		int TOTAL_ROWS = 3;
		int TOTAL_COLUMNS = 3;

		for( int row = 1 ; row <= TOTAL_ROWS ; row ++ ) {
			System.out.print( "Row = " + row + " |" );
			for( int col = 1 ; col <= TOTAL_COLUMNS ; col ++ ) {
				System.out.print( " Col = " + col);
			}
			// moves the control to the next line and prints next row iteration value 
			System.out.println();
		}
	}

}
