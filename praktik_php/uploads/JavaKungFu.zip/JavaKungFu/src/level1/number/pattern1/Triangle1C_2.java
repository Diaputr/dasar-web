package level1.number.pattern1;

public class Triangle1C_2 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {

			System.out.println();// move control to the next line

			// spaces to be printed before printing numbers
			for(int col = 1 ; col <= totalRows    ; col++) {
				int upper_limit = ( totalRows + 1 - row );
				if( col <= upper_limit  ) {
					System.out.print( upper_limit + " " );  
				}
			}
		}
	}
}
