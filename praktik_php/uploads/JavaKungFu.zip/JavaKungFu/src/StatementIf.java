
public class StatementIf {
	public static void main(String[] args) {
		int ageOfCitizen = 40;// value changed
		if( ageOfCitizen >= 60 ) {
			System.out.println("Age group - Senior Citizens.");
		}
	}
}


