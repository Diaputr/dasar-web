
public class ConvertLadderIfElseToSwitchCase {

	public static void main(String[] args) {

		int grade = 21;
		
		switch (grade) {
		case 1:
			System.out.println("35% fee refund.");
			break;
		case 2:
			System.out.println("25% fee refund.");
			break;
		case 3:
			System.out.println("20% fee refund.");
			break;
		case 4:
			System.out.println("10% fee refund.");
			break;
		case 5:
			System.out.println("Passed with margin.");
			break;
		case 0:
			System.out.println("Failed,please retry.");
			break;
		default:
			System.out.println("Invalid grade ? " + grade);
			break;
		}
	}
}
