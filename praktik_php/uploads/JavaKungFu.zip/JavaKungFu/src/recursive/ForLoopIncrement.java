package recursive;

public class ForLoopIncrement {

	public static void main(String[] args) {
		
		loopInc(1 ,10);
		
	}
	
	static void loopInc( int counter ,int totalRows) {
		// terminating condition
		if(  counter > totalRows ) {
			return;
		}
		// programming logic
		if(counter <= totalRows ) {
			System.out.println(counter);//print to console
		}
		// tail recursive call
		loopInc( counter + 1 ,totalRows);
	}
}
