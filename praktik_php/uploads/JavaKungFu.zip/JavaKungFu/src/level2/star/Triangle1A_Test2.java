package level2.star;
public class Triangle1A_Test2
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 10;  //number of rows to display
        
		StringBuilder rowBuilder = new StringBuilder("0123456789");
		for( int row = 0 ; row < totalRows ; row ++ ) {
			rowBuilder.deleteCharAt(row);
			rowBuilder.insert(row,"*");  
			System.out.println(rowBuilder.toString());

		}
	}
}
