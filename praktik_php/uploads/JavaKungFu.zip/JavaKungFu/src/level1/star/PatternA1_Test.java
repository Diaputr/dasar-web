package level1.star;
public class PatternA1_Test{
	public static void main(String[] args) {
		int  totalRows = 10;  //10 rows to display

		// Row level Repetitive Action : 
		// Action1.Execute's Column level Repetitive Action 
		// Action2.Move cursor to next row.
		for( int row = 1 ; row <= totalRows ; row ++ ) {
	 		// Column level Repetitive Action : 
			for(int col = 1 ; col <= row  ; col++) {
				// Action1.Move cursor in the same row
				// Action2.print �*� character 
				System.out.print("* ");  
			}
			System.out.println();// Move cursor to the next row

		}
	}
}
