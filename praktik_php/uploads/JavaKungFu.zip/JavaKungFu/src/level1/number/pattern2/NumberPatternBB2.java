package level1.number.pattern2;

public class NumberPatternBB2 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display
		
		// Row level Repetitive Action : 
		for( int row = 1 ; row <= totalRows ; row ++ ) {

			// Column level Repetitive Action : 
			// Action1.Move cursor in the same row
			// Action2.print character 	
			for( int col = totalRows ; col >= 1    ; col-- ) {
				if( col<=row )   {
					System.out.print( col + " " );  
				}else {
					System.out.print( "  " );
				}
			}
			// move control to the next line 
			System.out.println();
		}
	}
}
