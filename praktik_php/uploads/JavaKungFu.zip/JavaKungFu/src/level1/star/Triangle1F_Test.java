package level1.star;


public class Triangle1F_Test {

	public static void main(String[] args) {

		int  totalRows = 10;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {

			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
			//repetition happens 2 * totalRows  - 1 times horizontally  
			for(int col = 1 ; col <= ( 2 * totalRows  - 1 )   ; col++) {
				if( col >= row    && col <= ( 2 * totalRows   - row ) ) {
					System.out.print("* ");  
				}else {
					System.out.print("  ");
				}
			}

		}

	}

}
