package level2.star;


public class Triangle1D_Test2 {

	public static void main(String[] args) {

		int  totalRows = 10;  //number of rows to display
		//fill stars of size=totalRows,as star characters goes on decreases.
		StringBuilder rowBuilder = new StringBuilder();
		for(int count = 1 ; count <= totalRows; count ++ ) {
			rowBuilder.append("* ");
		}
		for( int row = 0 ; row < totalRows ; row ++ ) {

			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
			    // each row after the 1st row ,the  single star gets missing till remained 1 in the last.
				if( row > 0) {
					rowBuilder.setCharAt(2*(row-1),' ');  
					System.out.println(rowBuilder.toString());
				}else {
					System.out.println(rowBuilder.toString()); //leaving the 1st row
				}
				
		}

	}

}
