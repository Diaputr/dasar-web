package level3.arrays;

public class MoveZerosToEnd2 {
	
		static void bubbleSort( int[] arr ) {
			int last = arr.length - 1;
			int empty = 0;
		
	
			for ( int index = 0; index <  arr.length; index ++ ) {
				if(  index < last ) {
					if(arr[last] ==0) {
					System.out.println(arr[last]);
					last = last - 1;
					System.out.println(" last val:  " + last); 
					}
				}else {
					break; 
				}
				if(arr[index] == 0 && arr[last] !=0) {
					System.out.println( index + "," + arr[index]  + " : " + arr[last] + ", " + last);
					empty = arr[last];
					arr[last] = arr[index];
					arr[index] = empty;
					//last = last - 1;
					for(int val : arr) {
						System.out.print(val + " ," );
					}
				}
			}
		}
	   public static void main(String[] args) {
	      int arr[] = { 2, 5, 0, 6, 0, 8, 0, 6, 4, 0,4 };
	      System.out.println("Array Before Bubble Sort");
	      int fruitBoxes[] = {14, 0, 34, 0, 17, 13, 0, 32, 0, 25};
	      int totalBoxes = fruitBoxes.length;
	      int startPos = 0;
	      int endPos = totalBoxes - 1; //array�s index value starts from 0 not 1.
	      int index;//

	      for ( index = 0; startPos < endPos; index ++ ) {
	
	    	  System.out.println("startPos =  " + startPos + " , endPos = " + endPos);
		      System.out.println("=============== " + index);
		      System.out.println();

		      for(int i = 0; i < fruitBoxes.length; i++) {
		         System.out.print(fruitBoxes[i] + " ");
		      }
		      System.out.println();
	    	  
		      	//exchange the values zero and non-zero.
		      if(fruitBoxes[startPos] == 0 && fruitBoxes[endPos] !=0) {
		      	fruitBoxes[startPos] = fruitBoxes[endPos];
		      	fruitBoxes[endPos] = 0;
		      }
		      // If finds an empty box in his current position.<<Mr.Nice>>
		      // He should leave that box and moves to the next index position towards the end
		      if(fruitBoxes[startPos] != 0 )  {
		    	  startPos = startPos + 1; // next index position in the array.
		      }
		      //If finds an empty box in his current position. <<Mr.Noble>>
		      // He should leave that box and moves to the previous index position towards the zero index position 
		      // i.e., starting position of an array. 
		      
		      if( fruitBoxes[ endPos ] == 0 ) {
		    	  endPos = endPos - 1; // previous index position in the array.
		      }
		      // Checking of boxes completed.
//	    	  if(!( startPos < endPos )) {
//	    		  break;
//	    	  }		     
	      }



	     // bubbleSort(arr);
	      System.out.println("Array After Zeros Sort");

	      for(int i = 0; i < fruitBoxes.length; i++) {
	         System.out.print(fruitBoxes[i] + " ");
	      }
	   }

}
