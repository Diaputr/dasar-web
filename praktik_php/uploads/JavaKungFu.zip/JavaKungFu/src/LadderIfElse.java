
public class LadderIfElse {

	public static void main(String[] args) {
		
		int grade = 2;
		
		if(grade == 1) {
			System.out.println("35% fee refund.");
		}else if(grade == 2) {
			System.out.println("25% fee refund.");
		}else if(grade == 3) {
			System.out.println("20% fee refund.");
		}else if(grade == 4) {
			System.out.println("10% fee refund.");
		}else if(grade == 5) {
			System.out.println("Passed with margin.");
		}else if(grade == 0) {
			System.out.println("Failed,please retry.");
		}else  {
			System.out.println("Invalid grade ? " + grade);
		}
	}

}
