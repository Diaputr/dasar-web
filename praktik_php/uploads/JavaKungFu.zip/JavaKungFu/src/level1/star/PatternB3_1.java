package level1.star;
public class PatternB3_1{
	public static void main(String[] args) {
		int  totalRows = 10;  //10 rows to display
		// Row level Repetitive Action : 
		// Action1.Execute's Column level Repetitive Action 
		// Action2.Move cursor to next row.
		for( int row = totalRows ; row >=1  ; row -- ) {
			
	 		// Column level Repetitive Action : 
			for(int col = row; col >= 1 ; col--) {
				// Action1.Move cursor in the same row
				// Action2.print �*� character 
				System.out.print("* ");  
			}
			System.out.println();// Move cursor to the next row

		}
	}
}
