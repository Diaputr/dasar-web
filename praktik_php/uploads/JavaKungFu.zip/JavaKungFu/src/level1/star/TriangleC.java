package level1.star;


public class TriangleC {

	public static void main(String[] args) {

		int  totalRows = 10;  //number of rows to display

		draw(totalRows);

	}

	/**
	 * @param totalRows
	 */
	public static void draw(int totalRows) {
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			for(int col = 1 ; col <= (totalRows + 1) - row  ; col++) {
				System.out.print("* ");  
			}
			System.out.println();// move control to the next line where new set of characters will get printed.
		}
	}

	public static void draw(int totalRows, int shiftColums) { 
		
		StringBuffer  sb = new StringBuffer();
		for(int shift = 1 ; shift <= shiftColums ; shift++) {
			sb.append("  ");
		}
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			System.out.print(sb.toString());
			for(int col = 1 ; col <= (totalRows + 1) - row  ; col++) {
				System.out.print("* ");  
			}
			System.out.println();// move control to the next line where new set of characters will get printed.
		}
	}
}
