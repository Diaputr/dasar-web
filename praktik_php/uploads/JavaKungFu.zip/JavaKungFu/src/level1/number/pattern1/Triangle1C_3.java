package level1.number.pattern1;

public class Triangle1C_3 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {

			System.out.println();// move control to the next line 

			int upper_limit = ( totalRows + 1 - row );
			for(int col = 1 ; col <= upper_limit    ; col++) {
				System.out.print( upper_limit + " " );  
			}
		}
	}
}
