package level3.reuseLogic;

import level1.star.TriangleE;
import level1.star.TriangleF;

//TODO :  Not done.Using constructors to reverse the printing & non-printing chars.
public class ExerciseII {

	public static void main(String[] args) {
		int totalRows = 10;
		
		//reversing the design
		TriangleF  triF = new TriangleF( "  " , "* ");
		triF.draw(totalRows);
		
		TriangleE  triE = new TriangleE( "  " , "* ");
		triE.draw(totalRows );



	}

}
