package level1.star;


public class Triangle1F_2 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {

			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
			//repetition happens 5 times horizontally   (1 <=Col <=5)
			for(int col = 1 ; col <= ( 2 * totalRows  - 1 )   ; col++) {
				if( col >= row    && col <= ( 2 * totalRows   - row ) ) {
					System.out.print("* ");  
				}else {
					System.out.print("  ");
				}
			}

		}

	}

}
