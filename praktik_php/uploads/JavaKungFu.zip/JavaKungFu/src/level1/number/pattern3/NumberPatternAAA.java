package level1.number.pattern3;

public class NumberPatternAAA {

	public static void main(String[] args) {
		
		int  totalRows = 5;  //number of rows to display
		
		// Row level Repetitive Action : 
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			// Column level Repetitive Action : 
			// 1)Move cursor in the same row. 2)print character 
			for(int col = row ; col <= 2*row - 1  ; col++) {
				String num = col + " ";// added extra space for clarity in output.
				System.out.print( num );  
			}
			
			// move control to the next line 
			System.out.println();
		}
	}
}
