package level1.number.pattern3;

public class NumberPatternBBB2 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display
		// Row level Repetitive Action : 
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			// Column level Repetitive Action : 
			// 1)Move cursor in the same row. 2)print character 
			
			// spaces to be printed before printing numbers
			int num = 2*row - 1;//  horizontally   (2*row - 1 >= num >=row)
			// spaces to be printed before printing numbers
			for(int col = 1 ; col <= (totalRows)   ; col++) {
				if( col <= (totalRows - row) ) {
					System.out.print( "  " );  
				}else if( num >= row ) {
					// added extra space for clarity in output.
					String numStr = num  + " ";
					System.out.print( numStr );  
					num = num - 1;
				}
				
			}
			
			// move control to the next line 
			System.out.println();
		}
	}
}
