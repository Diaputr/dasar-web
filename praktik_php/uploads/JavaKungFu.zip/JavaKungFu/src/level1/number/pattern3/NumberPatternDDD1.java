package level1.number.pattern3;

public class NumberPatternDDD1 {

	public static void main(String[] args) {

		int totalRows = 5;  //number of rows to display
		int num;
		String numStr;
		String spaces = "  ";	// 2 spaces

		// Row level Repetitive Action : 
		for( int row = totalRows ; row >=1  ; row -- ) {

			// Column level Repetitive Action : 
			// 1)Move cursor in the same row. 
			// 2)print space character to before
			for( int col = 1; col <= ( totalRows - row ); col++ ) {
				System.out.print( spaces );   
			}// inner loop_1

			// num value to be printed 
			for( num = 2*row - 1 ; num >= row ; num -- ){
				numStr = num  + " ";
				System.out.print( numStr ); 
			}// inner loop_2

			// Move cursor to the next row
			System.out.println();
		}// outer loop 
	}

}
