package recursive;

public class Triangle1H_Test {

	public static void main( String[] args ) {

		int totalRows = 7;
		outerLoop(1, totalRows );

	}

	static void outerLoop( int row, int totalRows ) {
		int col = 1;// for every row , col = 1,... and hence 1 value as a parameter.

		// Row level Repetitive Action : printing single row.
		if ( row <= (2 * totalRows - 1) ) {

			// Action1.Execute's Column level Repetitive Action

			// 1st half
			if ( row <= totalRows ) {
				nestedLoopUpperHalf(col, row, totalRows );
			}
			// 2nd half
			if ( row > totalRows ) {
				nestedLoopLowerHalf(col, row, totalRows );
			}

			// Action2.Move cursor to next row.
			System.out.println();
		} else {
			return;// recursive call terminating condition
		}
		// next recursive call for the next row.
		outerLoop(row + 1, totalRows );
	}

	static void nestedLoopUpperHalf( int col, int row, int totalRows ) {
		// recursive call terminating condition
		if ( !(col <= (2 * totalRows - 1)) ) {
			return;
		}

		if ( (col <= (2 * totalRows - 1)) ) {
			if ( col >= (totalRows - row + 1) && col <= (totalRows + row - 1) ) {
				System.out.print("* " );
			} else {
				System.out.print("  " );
			}
		}
		// next recursive call for the next column.
		nestedLoopUpperHalf(col + 1, row, totalRows );

	}// end function

	static void nestedLoopLowerHalf( int col, int row, int totalRows ) {
		if ( (col <= (2 * totalRows - 1)) ) {
			if ( col >= (row - totalRows + 1) && col <= (3 * totalRows - (row + 1)) ) {
				System.out.print("* " );
			} else {
				System.out.print("  " );
			}
		} else {
			return; // recursive call terminating condition
		}
		// next recursive call for the next column.
		nestedLoopLowerHalf(col + 1, row, totalRows );

	}// end function

}
