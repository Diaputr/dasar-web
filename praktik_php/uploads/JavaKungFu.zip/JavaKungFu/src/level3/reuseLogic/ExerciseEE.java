package level3.reuseLogic;

import level1.star.TriangleB;
import level1.star.TriangleE;
import level1.star.TriangleA;

//TODO :  Not done.Using constructors to reverse the printing & non-printing chars.
public class ExerciseEE {

	public static void main(String[] args) {
		int totalRows = 10;
		
		//reversing the design
		TriangleE  triE1 = new TriangleE( "  " , "* ");
		triE1.draw(totalRows);


	}

}
