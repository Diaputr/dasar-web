package level1.number.pattern3;

public class TriangleC2_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int totalRows = 5; // number of rows to display

		for (int row = 0; row < totalRows; row++) {

			// spaces to be printed before printing numbers
			for (int col = (totalRows - row); col < 2 * ( totalRows - row)  ; col++) {
				String numStr = col + " ";// added extra space for clarity in output.
				System.out.print(numStr);
			} // inner loop

			System.out.println();// move control to the next line where new set of characters will get printed.
		}// outer loop

	}
}
