package level1.star;

public class TriangleB {

	public static void main(String[] args) {
		int  totalRows = 10;  //number of rows to display
		
		draw(totalRows);
	}

	/**
	 * @param totalRows
	 */
	public static void draw(int totalRows) {
		for( int row = 1 ; row <= totalRows ; row ++ ) {
				
				for( int col = 1; col <= totalRows  ; col ++) {
					
					if( col <= ( totalRows - row )  ) { 
						System.out.print( "  ");
					}else{
						System.out.print( "* "); 
					}
				}	
				System.out.println();// move control to the next line where new set of characters will get printed.
		}
	}

}
