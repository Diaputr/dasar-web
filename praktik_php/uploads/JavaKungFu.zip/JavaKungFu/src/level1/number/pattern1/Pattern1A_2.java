package level1.number.pattern1;

public class Pattern1A_2 {

	public static void main(String[] args) {

		int  totalRows = 7;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			System.out.println();// move to the next line 
			
			
			for(int col = 1 ; col <= row  ; col++) {
                        // added extra space for clarity in output.
				String num = row + " ";
				System.out.print( num );  
			}

		}
	}
}