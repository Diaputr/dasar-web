package level1.number.pattern1;

public class NumberPattern1F {

	public static void main(String[] args) {
		
		int totalRows = 7; // number of rows to display
		int num;
		
		// Row level Repetitive Action:
		for (int row = 1; row <= totalRows; row++) {
			
			// Column level Repetitive Action:
			
			// print the value of variable num
			for (int col = 1; col <= row; col++) {
				if (row % 2 == 1) {
					num = 1;
				} else {
					num = 0;
				}

				System.out.print(num + " ");
			} // inner loop - printing value in a column

			// Move cursor to the next row
			System.out.println();
		} // outer loop

	}

}
