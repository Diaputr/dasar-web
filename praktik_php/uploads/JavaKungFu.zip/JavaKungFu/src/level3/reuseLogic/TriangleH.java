package level3.reuseLogic;

import level1.star.TriangleE;
import level1.star.TriangleF;

public class TriangleH {

	public static void main(String[] args) {
		
		int totalRows = 10;
		TriangleE  triE = new TriangleE();	
		triE.draw(totalRows);
		
		TriangleF  triF = new TriangleF();
		triF.draw(totalRows-1,1 );
	}

}
