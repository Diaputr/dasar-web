package level3.arrays;

public class MoveZerosToEndOrdered {
	
		static void bubbleSort( int[] arr ) {
			int last = arr.length - 1;
			int empty = 0;
		
	
			for ( int index = 0; index <  arr.length; index ++ ) {
				if(  index < last ) {
					if(arr[last] ==0) {
					System.out.println(arr[last]);
					last = last - 1;
					System.out.println(" last val:  " + last); 
					}
				}else {
					break; 
				}
				if(arr[index] == 0 && arr[last] !=0) {
					System.out.println( index + "," + arr[index]  + " : " + arr[last] + ", " + last);
					empty = arr[last];
					arr[last] = arr[index];
					arr[index] = empty;
					//last = last - 1;
					for(int val : arr) {
						System.out.print(val + " ," );
					}
				}
			}
		}
	   public static void main(String[] args) {
	      int arr[] = { 2, 5, 0, 6, 0, 8, 0, 6, 4, 0,4 };
	      System.out.println("Array Before Bubble Sort");
	      int fruitBoxes[] = {14, 0, 34, 0, 17, 13, 0, 32, 0, 25};
	      int totalBoxes = fruitBoxes.length;
	      int endPos = totalBoxes - 1;//array�s index value starts from 0 not 1.
	      int startPos = 0;// Mr.Nice's starting position
	      int nextPos = startPos + 1;  // Mr.Nobel's starting position
	      int index;//

	      for ( index = 0; nextPos <= endPos; index ++ ) {
	
	    	  System.out.println("startPos =  " + startPos + " , nextPos = " + nextPos);
		      System.out.println("=============== " + index);
		      System.out.println();

		      for(int i = 0; i < fruitBoxes.length; i++) {
		         System.out.print(fruitBoxes[i] + " ");
		      }
		      System.out.println();
	    	  
		      	//exchange the values zero and non-zero.
		      if(fruitBoxes[startPos] == 0 && fruitBoxes[nextPos] !=0) {
		      	fruitBoxes[startPos] = fruitBoxes[nextPos];
		      	fruitBoxes[nextPos] = 0;
		      }
		      // If finds an empty box in his current position.<<Mr.Nice>>
		      // He should leave that box and moves to the next index position towards the end
		      if(fruitBoxes[startPos] != 0 )  {
		    	  startPos = startPos + 1; // next index position in the array.
		      }
		      //If finds an empty box in his current position. <<Mr.Noble>>
		      // He should leave that box and moves to the next index position till the last index position 
		     
		      if( fruitBoxes[ nextPos ] == 0 ) {
		    	  nextPos = nextPos + 1; // next index position in the array
		      }

	      }

	      System.out.println("Ordered array after moving zeros to end.");

	      for(int i = 0; i < fruitBoxes.length; i++) {
	         System.out.print(fruitBoxes[i] + " , ");
	      }
	   }

}
