package level1.number.pattern3;
/**
 * 
 *  Working formatting code can be applied to other java programs
 *
 */
public class TriangleD2_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 17;  //number of rows to display

		for( int row = totalRows ; row >=1  ; row -- ) {

			System.out.println();// move control to the next line where new set of characters will get printed.
			int num= 2*row - 1 ;
			// spaces to be printed 
			for(int col = 1; col <= ( totalRows )    ; col++) {
				if( col <= ( totalRows - row ) ) {
					if( col  < 10) {
						System.out.print( "   " );  //3 spaces for 1 digit number
					}else {
						System.out.print( "   " );  //1 spaces for 2 digit number
					}

				}else {

					if( num  < 10) {
						System.out.print( "  " + num  );  //2 spaces for 1 digit number
					}else {
						System.out.print(  " " +num);  //1 spaces for 2 digit number
					}
					num --;
				}
			}// end for 
		}
	}
}
