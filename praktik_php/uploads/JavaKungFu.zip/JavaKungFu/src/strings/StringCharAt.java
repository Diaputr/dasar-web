package strings;

public class StringCharAt {

	public static void main(String[] args) {
		
		String str = "Program";
		int index ;
		
		for( index = 0 ; index < str.length() ; index++) {
			String output = "str.charAt( "+ index + ") = " + str.charAt(index);
			System.out.println(output);
		}
	}

}
