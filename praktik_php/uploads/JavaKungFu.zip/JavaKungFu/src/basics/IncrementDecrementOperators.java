package basics;

public class IncrementDecrementOperators {

	public static void main(String[] args) {
		int  value = 100;
		int intResult ;
		System.out.println("Given values.");
		System.out.println("value = " + value );
		System.out.println();
		System.out.println("Incrementing 3 times");

		value++;
		value++;
		value++;
		System.out.println("Result = " + value);
		System.out.println();
		System.out.println("Decrementing 2 times");
		value--;
		value--;
		System.out.println("Result = " + value );

	}

}
