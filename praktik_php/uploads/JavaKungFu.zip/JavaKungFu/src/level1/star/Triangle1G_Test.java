package level1.star;


public class Triangle1G_Test {

	public static void main(String[] args) {

		int  totalRows = 15;  
		//number of rows to display
		for( int row = 1 ; row <= ( 2* totalRows - 1 ) ; row ++ ) {

			if(  row <= totalRows ) {
				System.out.println();
				for(int col = 1 ; col <= row  ; col++) {
					System.out.print("* ");  
				}
			}					

			if( row >totalRows ) {
				System.out.println();
				for(int col = 1 ; col <= ( 2* totalRows -  row  )   ; col++) {
					System.out.print("* ");  
				}
			}		


		}

	}

}
