package level1.star;
public class PatternG2 {
	public static void main(String[] args) {
		int totalRows = 5;// number of rows to display
		int colMax = 0;// defines the maximum limit for col variable.
		
		// Row level Repetitive Action : 
		// Action1.Execute's Column level Repetitive Action 
		// Action2.Move cursor to next row.
		for (int row = 1; row <= (2 * totalRows - 1); row++) {

			// sets the maximum limit of the inner for-loop
			if (row <= totalRows) {
				colMax = row;
			} else {
				colMax = ( 2 * totalRows - row );
			}
			
			// Column level Repetitive Action : 

			// Action1.Move cursor in the same row
			// Action2.prints star �* � character 
			for (int col = 1; col <= colMax ; col++) {
				System.out.print("* ");
			}// inner for-loop
			System.out.println();// Move cursor to next row.
		}// outer for-loop
	}
}
