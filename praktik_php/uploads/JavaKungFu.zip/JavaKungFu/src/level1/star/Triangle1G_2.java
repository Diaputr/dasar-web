package level1.star;

public class Triangle1G_2 {

	public static void main(String[] args) {

		int totalRows = 5;
		// number of rows to display
		for (int row = 1; row <= (2 * totalRows - 1); row++) {

			if (row <= totalRows) {
				for (int col = 1; col <= row; col++) {
					System.out.print("* ");
				}
			} else {
				for (int col = 1; col <= (2 * totalRows - row); col++) {
					System.out.print("* ");
				}
			}
			System.out.println();
		}

	}

}
