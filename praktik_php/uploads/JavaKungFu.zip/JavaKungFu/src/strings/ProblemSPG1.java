package strings;

public class ProblemSPG1 {

	public static void main( String[] args ) {
		int totalRows = 5;  // number of rows to display
		int count = 0;  	// counter to increment by 1.
		String line = "";	// intialize with blank string.
		
		for( int row = 1; row <= ( 2 * totalRows - 1 ); row++ ) {
			// Column level Repetitive Action : 
			if ( row <= totalRows ) {
				line = line.concat("*" + " ");
			} else {
			// increment count only when row > totalRows
			 count = count + 1;
			 line = line.substring( 0 , 2*(totalRows - count) );
			}
			System.out.print(line); 
			
			// Move to next row
			System.out.println();
		}
	}

}
