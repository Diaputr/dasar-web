package level1.star;
public class TriangleA
{

	public static void main(String[] args) {
		int  totalRows = 10;  //number of rows to display

		draw(totalRows);
		
	}

	/**
	 * @param totalRows
	 */
	public static  void draw(int totalRows) {
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			//repetition happens row number times horizontally   (1 <=Col <=row)
			for(int col = 1 ; col <= row  ; col++) {
				System.out.print("* ");  
			}
			 System.out.println();// move control to the next line where new set of characters will get printed.
		}
	}
	
	public static  void draw(int totalRows,int shiftColums) { 
		
		StringBuffer  sb = new StringBuffer();
		for(int shift = 1 ; shift <= shiftColums ; shift++) {
			sb.append("  ");
		}
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			System.out.print(sb.toString()); //prefix blank spaces for every row
			//repetition happens row number times horizontally   (1 <=Col <=row)
			for(int col = 1 ; col <= row  ; col++) {
				System.out.print("* ");  
			}
			 System.out.println();// move control to the next line where new set of characters will get printed.
		}
	}
}
