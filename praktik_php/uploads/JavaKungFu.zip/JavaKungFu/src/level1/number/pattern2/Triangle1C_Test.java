package level1.number.pattern2;

public class Triangle1C_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 7;  //number of rows to display

		for( int row = 0 ; row < totalRows ; row ++ ) {

			System.out.println();// move control to the next line where new set of characters will get printed.

			// spaces to be printed before printing numbers
			for(int col = 1 ; col <= totalRows    ; col++) {
				if( col <= (totalRows  - row) ) {
					System.out.print( col + " " );  
				}else {
					System.out.print( "  " );  
				}
			}
		}
	}
}
