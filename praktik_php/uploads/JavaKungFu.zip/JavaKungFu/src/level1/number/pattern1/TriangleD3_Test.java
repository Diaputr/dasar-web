package level1.number.pattern1;

public class TriangleD3_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 7;  //number of rows to display

		for( int row = totalRows ; row >=1  ; row -- ) {

			System.out.println();// move control to the next line where new set of characters will get printed.

			for(int col = totalRows; col >= 1    ; col--) {
				if( col <=  row ) {
					System.out.print( row + " " );  // row value to be printed 
				}else {
					System.out.print( "  " );  // spaces to be printed 
				}

			}
		}
	}
}
