package recursive;
public class PatternA1_Test{
	public static void main(String[] args) {
		int  totalRows = 7;  //10 rows to display

		outerLoop( 1 , totalRows);
	}
	
	static void nestedLoop( int col , int row) {
		// call terminating condition
		if( ! ( col <= row) ) {
			return;
		}
		
		if( col <= row ){
			System.out.print("* ");  
		}
		nestedLoop( col + 1, row);
		
	}
	
	static void outerLoop( int row ,  int totalRows) {
		// call terminating condition
		if( ! ( row <= totalRows) ) {
			return;
		}
		
		// Row level Repetitive Action : 
		if( row <= totalRows ){
			// Action1.Execute's Column level Repetitive Action 
			nestedLoop( 1, row);// for every row , col = 1,... and hence 1 value as a parameter.
			
			// Action2.Move cursor to next row.
			System.out.println();
		}
		// next recursive call for the next row.
		outerLoop( row + 1 ,  totalRows);
	}
}
