package level3.reuseLogic;

import level1.star.TriangleA;
import level1.star.TriangleC;


public class ExerciseCC {

	public static void main(String[] args) {
		int totalRows = 10;
		
		
		TriangleC.draw(totalRows);
		TriangleA.draw(totalRows);

	}

}
