package level3.reuseLogic;

import level1.star.TriangleA;
import level1.star.TriangleC;
import level1.star.TriangleD;


public class ExerciseAA {

	public static void main(String[] args) {
		int totalRows = 10;
		
		TriangleA.draw(totalRows,totalRows - 1);
		TriangleD.draw(totalRows );

	}

}
