package level1.number.pattern3;

public class TriangleC1_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 5;  //number of rows to display

		for( int row = totalRows ; row >= 1 ; row -- ) {

			System.out.println();// move control to the next line where new set of characters will get printed.
			int num = row ;
			// spaces to be printed before printing numbers
			for(int col = 1 ; col <= row   ; col++) {
			 if( num >= row  && num <= 2*row - 1) {
					String numStr = num  + " ";// added extra space for clarity in output.
					System.out.print( numStr );  
					num = num  + 1;
				}
				
			}
			
			
		}
	}
}
