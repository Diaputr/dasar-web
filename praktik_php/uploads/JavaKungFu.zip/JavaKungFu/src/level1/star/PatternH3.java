package level1.star;
public class PatternH3 {

	public static void main( String[] args ) {

		int totalRows = 5;  //number of rows to display
		int spaceMax  = totalRows - 1;// maximum count to print space �  �
		int starMax  = 1;// maximum count to print star �* �

		// Row level Repetitive Action : 
		// Action1.Execute's Column level Repetitive Action 
		// Action2.Move cursor to next row.
		for( int row = 1 ; row <= ( 2* totalRows - 1 ) ; row ++ ) {

			//Column level Repetitive Action : Print space in the same row
			for(int col = 1 ; col <= spaceMax ; col++) {
					System.out.print("  ");  
			}//inner for-loop_1
			
			//Column level Repetitive Action : Print star in the same row
			for(int col  = 1 ; col <= starMax ; col++ ) {
					System.out.print("* ");  
			}//inner for-loop_2			
			
			System.out.println();// Move cursor to next row.
			
			if ( row < totalRows ){
				spaceMax = ( spaceMax  -  1 );
				starMax = ( starMax + 2 );
			}else{
				spaceMax = ( spaceMax  +  1 );
				starMax = ( starMax - 2 );
			}
			
		}// outer for-loop
	}
}
