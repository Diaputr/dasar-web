package level1.number.pattern2;

public class NumberPatternFF2 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display
		int lw_lt_num;
		int lw_lt_spaces;
		int up_lt_spaces;
		int numSet1;
		String numSet1Str;
		int numSet2 = 0;
		String numSet2Str;
		String spaces = "  ";// 2 spaces
		// Row level Repetitive Action : 
		for( int row = 0 ; row < totalRows ; row ++ ) {
			// Column level Repetitive Action : 
			for( int col = 1 ; col <= ( 2* totalRows  - 1 ) ; col++) {
				// use of ternary operator, an simpler if-else shortcut
				lw_lt_num = (row == 0)? ( totalRows - 1 ) : ( totalRows - row );
				lw_lt_spaces = (row == 0)? 0 : ( totalRows - row + 1 );
				up_lt_spaces = (row == 0)? -1 : (totalRows + row - 1 );

				if( col <= lw_lt_num ){
					numSet1 = col;
					numSet1Str = numSet1 + " ";
					System.out.print( numSet1Str ); 
					// updating numSet2 when numSet1 reach it's 
		            // maximum value
					if(col == lw_lt_num ){
						numSet2 = numSet1; 
					}
				}else if( col >= lw_lt_spaces && 
					col <= up_lt_spaces ) {
					System.out.print( spaces );		  
				}else {
					// first row where no space is required to print.
					if(row == 0 && col == totalRows ){
						numSet2 = totalRows;
					}
					numSet2Str = numSet2 + " ";
					numSet2 = numSet2 - 1;
					System.out.print(numSet2Str);  
						
				}
			}// inner loop

			// Move cursor to the next row
			System.out.println();

		}// outer loop 
	}

}
