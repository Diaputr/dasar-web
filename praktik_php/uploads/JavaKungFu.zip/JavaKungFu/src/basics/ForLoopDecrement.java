package basics;

public class ForLoopDecrement {

	public static void main(String[] args) {
		
		for ( int counter = 5 ; counter >= 1; counter -- ){
			System.out.println( counter ); //print to console
		}
		
	}
}
