package strings;

public class StringPatternAA1 {

	public static void main( String[] args ) {
		
		int totalRows = 5;  // number of rows to display
		String line = "";	// Initialize with blank string.

		for( int row = 1 ; row <= totalRows ; row ++ ) {
			// Column level Repetitive Action : 
			line = line.concat( row + " " );
			System.out.print(line); 
			
			// Move cursor to the next row
			System.out.println();
		}
	}
}
