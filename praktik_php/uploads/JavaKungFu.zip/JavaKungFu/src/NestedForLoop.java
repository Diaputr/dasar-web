public class NestedForLoop {

	public static void main(String[] args) {

		for( int out = 1 ; out <= 2 ; out++ ) {
			System.out.println("OUTER count No." + out);
			// nested for-loop: always re-starts and finishes completely
			// for every new value of outer for-loop.
			for( int in = 1 ; in <= 3 ; in++) {
				System.out.println(" <INNER> count No." + in );
			}
		}
	}

}

