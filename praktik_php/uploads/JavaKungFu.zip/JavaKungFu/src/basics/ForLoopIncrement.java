package basics;

public class ForLoopIncrement {

	public static void main(String[] args) {
		
		for ( int counter = 1 ; counter <=10 ; counter ++ ){
			System.out.println(counter);//print to console
		}
		
	}
}
