package level1.number.pattern2;

public class Triangle1B_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 7;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {

			System.out.println();// move control to the next line where new set of characters will get printed.

			// spaces to be printed before printing numbers
			for(int col = 1 ; col <= (totalRows - row)   ; col++) {
				System.out.print( "  " );  
			}
			//repetition happens row number times horizontally   (row >= num >=1)
			for(int num = row ; num >=  1 ; num--) {
				String numStr = num  + " ";// added extra space for clarity in output.
				System.out.print( numStr );  
			}
		}
	}
}
