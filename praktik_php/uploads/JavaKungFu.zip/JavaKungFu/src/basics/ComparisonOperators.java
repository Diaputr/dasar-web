package basics;
public class ComparisonOperators {

	public static void main(String[] args) {
		int four = 4;
		int six = 6;
		int ten = 10;
		boolean isResult;
		String operatorStr;
		String expressionStr;
		String resultStr;
		
		String header = "Description           | Operator | Expression  | Result " ;
		String line = "--------------------------------------------------------";
		System.out.println("*** Comparison Operators ***");
		System.out.println();
		
		System.out.println(header);
		System.out.println(line);
		
		operatorStr = "equal                 | ==       | ";
		expressionStr = four + " == " + four + "      | ";
		isResult = ( four == four ) ;
		System.out.println( operatorStr + expressionStr + isResult );
		
		expressionStr = four + " == " + ten + "     | ";
		isResult = ( four == ten ) ;
		System.out.println( operatorStr + expressionStr + isResult );
		System.out.println(line);
		
		operatorStr = "not equal             | !=       | ";
		expressionStr = six + " != " + four + "      | ";
		isResult = ( six != four ) ;
		System.out.println( operatorStr + expressionStr + isResult );
		
		expressionStr = four + " != " + four +"      | ";
		isResult = ( four != four ) ;
		System.out.println( operatorStr + expressionStr + isResult );
		System.out.println(line);
		
		operatorStr = "less than             | <        | " ;
		expressionStr = six + " < " + six + "       | ";
		isResult = ( six < ten ) ;
		System.out.println( operatorStr + expressionStr + isResult );
		
		expressionStr = six + " < " + ten + "      | ";
		isResult = ( six < six ) ;
		System.out.println( operatorStr + expressionStr + isResult );
		System.out.println(line);
		
		operatorStr = "less than or equal    | <=       | " ;
		expressionStr = six + " <= " + six + "      | ";
		isResult = ( six <= six ) ;
		System.out.println( operatorStr + expressionStr + isResult );
		
		expressionStr = ten + " <= " + six + "     | ";
		isResult = ( ten <= six ) ;
		System.out.println( operatorStr + expressionStr + isResult );
		System.out.println(line);
		
		operatorStr = "greater than          | >        | " ;
		expressionStr = six + " > " + six + "       | ";
		isResult = ( six > six ) ;
		System.out.println( operatorStr + expressionStr + isResult );
		
		expressionStr = ten + " > " + six + "      | ";
		isResult = ( ten > six ) ;
		System.out.println( operatorStr + expressionStr + isResult );
		System.out.println(line);
		
		operatorStr = "greater than or equal | >=       | "  ;
		expressionStr = four + " >= " + six + "      | ";
		isResult = ( four >= six ) ;
		System.out.println( operatorStr + expressionStr + isResult );
		
		expressionStr = ten + " >= " + six + "     | ";
		isResult = ( ten >= six ) ;
		System.out.println( operatorStr + expressionStr + isResult );
		System.out.println(line);
	}

}
