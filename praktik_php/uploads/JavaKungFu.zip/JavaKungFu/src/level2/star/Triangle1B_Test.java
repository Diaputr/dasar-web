package level2.star;

public class Triangle1B_Test {

	public static void main(String[] args) {
		int  totalRows = 10;  //number of rows to display
		int col ;
		
		//fill spaces of size=totalRows
		StringBuilder rowBuilder = new StringBuilder();
		for(col = 1 ; col <= totalRows; col ++ ) {
			rowBuilder.append(" ");
		}
		
		for( int row = 1 ; row <=totalRows ; row ++ ) {

			col = totalRows - row ;
			//rowBuilder.deleteCharAt(col);
			rowBuilder.setCharAt(col,'*');  
			System.out.println(rowBuilder.toString());
	
		}	

	}
}


