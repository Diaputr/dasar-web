package level1.star;

public class Triangle1B_1 {

	public static void main(String[] args) {
		int  totalRows = 5;  //number of rows to display
		
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			if( row == 1) {
				System.out.println();
				
				for( int col = 1; col <= totalRows  ; col ++) {
					
					if(col  >=1 &&  col <= 4) {
						System.out.print( "  ");
					}
					
					if(col == 5) {
						System.out.print( " *");
					}
				}

			}
			
			if( row == 2) {
				System.out.println();
				for( int col = 1; col <= totalRows ; col ++) {
					
					if(col  >=1 &&  col <= 3) {
						System.out.print( "  ");
					}
					
					if(col  >=4 && col  <= 5) {
						System.out.print( " *");
					}
				}
			}
			
			if( row == 3 ) {
				System.out.println();
				for( int col = 1; col <= totalRows ; col ++) {
					
					if(col  >=1 &&  col <= 2) {
						System.out.print( "  ");
					}
					
					if(col  >=3 && col  <= 5) {
						System.out.print( " *");
					}
				}
			}			
			
			if( row == 4 ) {
				System.out.println();
				for( int col = 1; col <= totalRows ; col ++) {
					
					if(col  >=1 &&  col <= 1) {
						System.out.print( "  ");
					}
					
					if(col  >=2  && col  <= 5) {
						System.out.print( " *");
					}
				}
			}			
			
			if( row == 5 ) {
				System.out.println();
				for( int col = 1 ; col <= totalRows ; col ++) {
					System.out.print( " *");
				}
			}						
		}
	}

}
