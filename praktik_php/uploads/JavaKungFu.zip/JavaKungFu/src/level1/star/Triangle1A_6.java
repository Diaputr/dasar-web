package level1.star;
public class Triangle1A_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 5;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			System.out.println();
			//repetition happens row number times horizontally   (1 <=Col <=row)
			for(int col = 1 ; col <= row  ; col++) {
				System.out.print("* ");  
			}

		}
	}
}
