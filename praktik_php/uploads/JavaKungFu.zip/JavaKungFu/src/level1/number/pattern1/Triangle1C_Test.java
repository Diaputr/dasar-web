package level1.number.pattern1;

public class Triangle1C_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 7;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {

			System.out.println();// move control to the next line where new set of characters will get printed.

			int upper_limit = ( totalRows + 1 - row );
			for(int col = 1 ; col <= upper_limit    ; col++) {
				System.out.print( upper_limit + " " );  
			}
		}
	}
}
