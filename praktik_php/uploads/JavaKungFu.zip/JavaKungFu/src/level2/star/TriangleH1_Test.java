package level2.star;


public class TriangleH1_Test {

	public static void main(String[] args) {

		int  totalRows = 10;  
		//number of rows to display
		
		//fill spaces of size=totalRows,as space characters goes on decreases.
		StringBuilder rowBuilder = new StringBuilder();
		for(int count = 1 ; count <= ( 2* totalRows ) ; count ++ ) {
			rowBuilder.append(" ");
		}
		
		int col = 1;
		
		for( int row = 1 ; row <= ( 2* totalRows - 1 ) ; row ++ ) {

			//1st half
			if(  row <= totalRows ) {
				// repetition happens 2* totalRows  - 1 times horizontally   (1 <=Col <=9)
				// since rowBuilder starts it index = 0 ,so -1 in first parameter
				String column = rowBuilder.substring(  ( (totalRows - row) + 1 - 1), ( (  totalRows + row )  - 1) );
				column = column.replace(" ", "*");

				rowBuilder.replace(   ( (totalRows - row) + 1 - 1), ( (  totalRows + row )  - 1)  ,column);  
				System.out.println(rowBuilder.toString());
			}					

			// 2nd half 
			if( row >totalRows ) {
				//replacing space with star from both the ends and printing it.
				if( col >= 1    ) {
					rowBuilder.setCharAt( ( col - 1 ) ,' ') ;
					rowBuilder.setCharAt( (2 * totalRows   - col - 1)  ,' ');
					System.out.println(rowBuilder.toString());  
					col++;
				}
				
			}		

		}

	}

}
