package level1.number.pattern2;


public class NumberPatternEE {

	public static void main(String[] args) {

		int  totalRows = 8;  //number of rows to display
		
		// Row level Repetitive Action : 
		for( int row = 1 ; row <= totalRows ; row ++ ) {

			//repetition count (2* totalRows  - 1) happens horizontally
			int num = row;
			
			// Column level Repetitive Action : 
			// Action1.Move cursor in the same row
			// Action2.print character 
			for(int col = 1 ; col <= ( 2* totalRows  - 1 ) ; col++) {
				
				if( col >= ( (totalRows - row) + 1 ) && 
					col <= (  (  totalRows + row )  - 1 ) ) {
					if(col < totalRows ) {
						System.out.print(num+" ");  
						num = num -1;
					}else if(col >=totalRows) {
						System.out.print(num+" ");  
						num = num +1;
					}
				
				}else {
					System.out.print("  ");
				}
			}//end  inner for - loop 
			
			// move control to the next line 
			System.out.println();
		}
	}

}
