package level3.arrays;

public class MoveZerosToEnd {
	
		static void bubbleSort( int[] arr ) {
			int last = arr.length - 1;
			int empty = 0;
		
	
			for ( int index = 0; index <  arr.length; index ++ ) {
				if(  index < last ) {
					if(arr[last] ==0) {
					System.out.println(arr[last]);
					last = last - 1;
					System.out.println(" last val:  " + last); 
					}
				}else {
					break; 
				}
				if(arr[index] == 0 && arr[last] !=0) {
					System.out.println( index + "," + arr[index]  + " : " + arr[last] + ", " + last);
					empty = arr[last];
					arr[last] = arr[index];
					arr[index] = empty;
					//last = last - 1;
					for(int val : arr) {
						System.out.print(val + " ," );
					}
				}
			}
		}
	   public static void main(String[] args) {
	      int arr[] = { 2, 5, 0, 6, 0, 8, 0, 6, 4, 0,4 };
	      System.out.println("Array Before Bubble Sort");

	      for(int i = 0; i < arr.length; i++) {
	         System.out.print(arr[i] + " ");
	      }
	      System.out.println();
	      bubbleSort(arr);
	      System.out.println("Array After Bubble Sort");

	      for(int i = 0; i < arr.length; i++) {
	         System.out.print(arr[i] + " ");
	      }
	   }

}
