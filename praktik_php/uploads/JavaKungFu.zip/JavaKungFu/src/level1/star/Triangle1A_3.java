package level1.star;

public class Triangle1A_3 {

	public static void main(String[] args) {
		
		int  totalRows = 5;  //number of rows to display
		
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			// use of && operator to reduce to single if-condition.
			if( ( 1<= row )  &&  ( row <= 5 ) ){
				System.out.println();
			      //repetition happens horizontally (1<=Col<=row )
				for(int col = 1 ; col <= row  ; col++) {
					System.out.print("* ");  
				}// inner for-loop
				
			}

		}//outer for-loop

	}

}
