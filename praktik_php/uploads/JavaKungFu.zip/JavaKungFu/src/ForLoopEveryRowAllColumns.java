
public class ForLoopEveryRowAllColumns {

	public static void main(String[] args) {
		int TOTAL_ROWS = 3;
		int TOTAL_COLUMNS = 3;

		for( int row = 1 ; row <= TOTAL_ROWS ; row ++ ) {
			for( int col = 1 ; col <= TOTAL_COLUMNS ; col ++ ) {
				System.out.println( "Row = " + row +"|" +" Col = " + col);
			}
			System.out.println("--------------------------------");
		}
	}

}
