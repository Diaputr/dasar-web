package level1.star;


public class TriangleE {
	
	// default value
	private  String charsForDesign; 
	private  String charsNotForDesign;
	
	
	public TriangleE( String charsForDesign, String charsNotForDesign ) {
		super();
		this.charsForDesign = charsForDesign;
		this.charsNotForDesign = charsNotForDesign;
	}

	public TriangleE() {
		this.charsForDesign = "* " ;
		this.charsNotForDesign = "  ";
	}

	public String getCharsForDesign() {
		return charsForDesign;
	}

	public String getCharsNotForDesign() {
		return charsNotForDesign;
	}

	public static void main(String[] args) {
		int  totalRows = 10;  //number of rows to display
		
		TriangleE  triE = new TriangleE();
	   	triE.draw(totalRows);
		//triE.draw(totalRows);
		
		//reversing the design
		System.out.println( " reversing the design");
		TriangleE  triE1 = new TriangleE( "  " , "* ");
		triE1.draw(totalRows);
	}

	/**
	 * @param totalRows
	 */
	public  void draw(int totalRows) {
		drawTopCut(totalRows, 0);
	}

	public  void drawTopCut(int totalRows,int skipRows) {
		for( int row = skipRows ; row <= totalRows ; row ++ ) {
			
			//repetition happens 2* totalRows  - 1 times horizontally   (1 <=Col <=9)
			for(int col = 1 ; col <= ( 2* totalRows  - 1 ) ; col++) {
				
				if( col >= ( (totalRows - row) + 1 )    && col <= (  (  totalRows + row )  - 1 )   ) {
				System.out.print(charsForDesign);  
				}else {
					System.out.print(charsNotForDesign);
				}
			}//end  inner for - loop 
			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
		}//end  outer for - loop 
	}

	public   void draw(int totalRows,int shiftColums) { 
		
		StringBuffer  sb = new StringBuffer();
		for(int shift = 1 ; shift <= shiftColums ; shift++) {
			sb.append("  ");
		}
		
		for( int row = 1 ; row <= totalRows ; row ++ ) {
			
			System.out.print(sb.toString()); //prefix blank spaces for every row
			
			//repetition happens 2* totalRows  - 1 times horizontally   (1 <=Col <=9)
			for(int col = 1 ; col <= ( 2* totalRows  - 1 ) ; col++) {
				
				if( col >= ( (totalRows - row) + 1 )    && col <= (  (  totalRows + row )  - 1 )   ) {
				System.out.print(charsForDesign);  
				}else {
					System.out.print(charsNotForDesign);
				}
			}//end  inner for - loop 
			System.out.println();// move control to the next line where new set of characters will get printed horizontally.
		}//end  outer for - loop
	}
	
}
