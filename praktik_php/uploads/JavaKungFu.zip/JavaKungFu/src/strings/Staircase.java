package strings;

public class Staircase {

	public static void main( String[] args ) {
		String str  = "Programming";
		String spaces = "";
		for( int index = 0 ; index < str.length() ; index++) {
			spaces = spaces.concat("_");
			String print  = str.charAt(index) + spaces ;
			print = print + "|"+ spaces + str.charAt (index);
			System.out.println( print );
		} 

	}

}
