package level1.star;
public class PatternH2_2 {

	public static void main( String[] args ) {

		int totalRows = 5;  //number of rows to display
		int colMin = 0;// column position to start printing �*�
		int colMax = 0;// column position to stop printing �*�

		// Row level Repetitive Action : 
		// Action1.Execute's Column level Repetitive Action 
		// Action2.Move cursor to next row.
		for( int row = 1 ; row <= ( 2* totalRows - 1 ) ; row ++ ) {

			if ( row <= totalRows ){
				colMin = ( totalRows  -  row );
				colMax = ( totalRows + row );
			}else{
				colMin = ( row -  totalRows );
				colMax = ( 3 * totalRows - row );
			}

			//Column level Repetitive Action : 
			for(int col = 1 ; col < colMax ; col++) {
				if( col > colMin  ) {
					System.out.print("* ");  
				}else {
					System.out.print("  ");  
				}
			}//inner for-loop
			
			System.out.println();// Move cursor to next row.
			
		}// outer for-loop
	}
}
