package level1.number.pattern3;

public class NumberPatternCCC2 {

	public static void main(String[] args) {

		int totalRows = 5;  //number of rows to display
		String numStr;

		// Row level Repetitive Action : 
		for( int row = 0; row < totalRows; row++) {

			// Column level Repetitive Action : 
			// 1)Move cursor in the same row. 2)print character 
			for( int col=(totalRows - row);col<2*(totalRows - row); col++ ) {
				numStr = col  + " ";
				System.out.print( numStr ); 
			}// inner loop	

			// Move cursor to the next row
			System.out.println();

		}// outer loop 
	}

}
