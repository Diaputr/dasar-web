package level1.star;


public class Triangle1H_Test {

	public static void main(String[] args) {

		int  totalRows = 10;  
		//number of rows to display
		for( int row = 1 ; row <= ( 2* totalRows - 1 ) ; row ++ ) {

			//1st half
			if(  row <= totalRows ) {
				System.out.println();
				for(int col = 1 ; col <= ( 2* totalRows - 1 ) ; col++) {
					if( col >= ( totalRows  -  row  + 1 )  && col<= ( totalRows  + row -1 ) ) {
						System.out.print("* ");  
					}else {
						System.out.print("  ");  
					}
					
				}
			}					

			// 2nd half 
			if( row >totalRows ) {
				System.out.println();
				for(int col = 1 ; col <= ( 2* totalRows -  1  )   ; col++) {
					if( col >= ( row -  totalRows + 1 )  && col<= ( 3* totalRows  -   ( row   + 1 )   ) ) {
						System.out.print("* ");  
					}else {
						System.out.print("  ");  
					}
				}
			}		

		}

	}

}
