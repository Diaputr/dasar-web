package level1.number.pattern3;

public class TriangleC1_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  totalRows = 7;  //number of rows to display

		for( int row = totalRows ; row >= 1 ; row -- ) {

			System.out.println();// move control to the next line where new set of characters will get printed.
			// spaces to be printed before printing numbers
			for(int col = row ; col <= ( 2*row - 1 )   ; col++) {
				String numStr = col  + " ";// added extra space for clarity in output.
				System.out.print( numStr );  
			}

		}
	}
}

