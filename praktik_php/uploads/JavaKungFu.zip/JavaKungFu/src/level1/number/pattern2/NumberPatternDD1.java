package level1.number.pattern2;

public class NumberPatternDD1 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display
		
		// Row level Repetitive Action : 
		for( int row = 1 ; row <= totalRows ; row ++ ) {

			// Column level Repetitive Action : 
			// Action1.Move cursor in the same row
			// Action2.print character 	
			
			// spaces to be printed before printing numbers
			for( int col = totalRows ; col >= 1 ; col -- ) {
				
				if( col >= 1 &&  col <= (totalRows + 1 - row) ) {
					System.out.print( col + " " );  
				}else {
					System.out.print( "  " );  
				}
				
			}// inner for-loop
			
			// move control to the next line 
			System.out.println();
		}
	}
}
