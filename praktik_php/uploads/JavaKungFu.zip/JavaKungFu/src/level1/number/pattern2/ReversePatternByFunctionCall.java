package level1.number.pattern2;

public class ReversePatternByFunctionCall {

	public static void main( String[] args ) {

		// main program
		int unicode_A = 65;// unicode for letter A
		String spaces4 = "    ";// 4 spaces - formatting output
		int unicode_a = 97;// unicode for letter a
		String spaces3 = "   ";// 3 spaces - formatting output
		int unicode_1 = 49;// unicode for digit 1.
		System.out.println("Print Capital Letter Pattern" );
		System.out.println("-----------------------------------" );
		printPattern(unicode_A, spaces4 );

		System.out.println();
		System.out.println("Print Small Letter Pattern" );
		System.out.println("-----------------------------------" );
		printPattern(unicode_a, spaces3 );

		System.out.println();
		System.out.println("Print Number Pattern FF" );
		System.out.println("-----------------------------------" );
		printPattern(unicode_1, spaces3 );
	}

	static void printPattern( int unicode, String spaces ) { // function declaration
		int totalRows = 5; // number of rows to display
		int lw_lt_num;
		int lw_lt_spaces;
		int up_lt_spaces;
		int numSet1;
		String numSet1Str;
		int numSet2 = 0;
		String numSet2Str;

		spaces = "  ";// 2 spaces

		// Row level Repetitive Action :
		for ( int row = (totalRows-1) ; row >= 0 ; row -- ) {

			// Column level Repetitive Action :
			// 1)Move cursor in the same row. 2)print character
			for ( int col = 1; col <= (2 * totalRows - 1); col++ ) {

				// switching the lower_limit or upper_limit logical expressions
				lw_lt_num = (row == 0) ? (totalRows - 1) : (totalRows - row);
				lw_lt_spaces = (row == 0) ? 0 : (totalRows - row + 1);
				up_lt_spaces = (row == 0) ? -1 : (totalRows + row - 1);

				if ( col <= lw_lt_num ) {
					numSet1 = col + (unicode - 1);
					numSet1Str = (char) numSet1 + " ";
					System.out.print(numSet1Str );
					// updating numSet2 when numSet1 reach it's maximum value
					if ( col == lw_lt_num ) {
						numSet2 = numSet1;
					}

				} else if ( col >= lw_lt_spaces && col <= up_lt_spaces ) {
					System.out.print(spaces );
				} else {
					// first row where no space is required to print.
					if ( row == 0 && col == totalRows ) {
						numSet2 = totalRows + (65 - 1);
					}
					numSet2Str = (char) numSet2 + " ";
					numSet2 = numSet2 - 1;
					System.out.print(numSet2Str );

				}
			} // inner loop
				// Move cursor to the next row
			System.out.println();

		} // outer loop

	}// method ends here

}
