package level2.star;

//formatting the output with single space gap.
public class Triangle1B_Test2 {

	public static void main(String[] args) {
		int  totalRows = 10;  //number of rows to display
		int col ;
		
		//fill spaces of size=totalRows,as space characters goes on decreases.
		StringBuilder rowBuilder = new StringBuilder();
		for(col = 1 ; col <= 2*totalRows; col ++ ) {
			rowBuilder.append(" ");
		}
		
		for( int row = 1 ; row <=totalRows ; row ++ ) {

			col = totalRows - row ;
			//rowBuilder.deleteCharAt(col);
			rowBuilder.setCharAt(2*col,'*');  
			System.out.println(rowBuilder.toString());
	
		}	

	}
}


