package level1.star;


public class Triangle1C_2 {

	public static void main(String[] args) {

		int  totalRows = 5;  //number of rows to display

		for( int row = 1 ; row <= totalRows ; row ++ ) {

			if( row == 1) {
				System.out.println();
				//repetition happens 5 times horizontally   (1 <=Col <=5)
				for(int col = 1 ; col <= totalRows  ; col++) {
					System.out.print("* ");  
				}
			}					

			if( row == 2) {
				System.out.println();
				//repetition happens 4 times horizontally   (1 <=Col <=4)
				for(int col = 1 ; col <= (totalRows -1 )  ; col++) {
					System.out.print("* ");  
				}
			}		

			if( row == 3) {
				System.out.println();
				//repetition happens 3 times horizontally   (1 <=Col <=3)
				for(int col = 1 ; col <= (totalRows - 2 )  ; col++) {
					System.out.print("* ");  
				}
			}	

			if( row == 4) {
				System.out.println();
				//repetition happens 2 times horizontally   (1 <=Col <=2)
				for(int col = 1 ; col <= ( totalRows - 3 ) ; col++) {
					System.out.print("* ");  
				}

			}

			if( row == 5) {
				System.out.println();
				// 1 time   (1 <=Col <=1)
				for(int col = 1 ; col <=( totalRows - 4 )  ; col++) {
					System.out.print("* ");  
				}
			}
		}

	}

}
