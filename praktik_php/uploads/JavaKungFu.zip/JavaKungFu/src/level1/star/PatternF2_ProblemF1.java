package level1.star;

public class PatternF2_ProblemF1 {
	
	public static void main(String[] args) {
		int  totalRows = 5;  // total number of rows to display

		// Row level Repetitive Action : 
		// Action1.Execute's Column level Repetitive Action 
		// Action2.Move cursor to next row.
		for( int row = 1 ; row  <= totalRows ; row ++ ) {
	 		// Column level Repetitive Action : 
			
			// Action1.Move cursor in the same row
			for(int col = 1 ; col <= ( 2 * totalRows  - row ) ; col++) {
		
				if( col >= row  ) {
					// Action2.prints star �* � character 
					System.out.print("* ");  
				}else {
					// Action3.prints space � � character 
					System.out.print("  ");  
				}
				
			}// inner for-loop
			
			System.out.println();// Move cursor to the next row

		}// outer for-loop
	}
}
