package level1.number.pattern1;

public class TriangleD1_1 {

	public static void main(String[] args) {
		
		int  totalRows = 5;  //number of rows to display

		for( int row = totalRows ; row >=1  ; row -- ) {

			System.out.println();// move control to the next line 
			
			// spaces to be printed 
			for(int col = 1; col <= ( totalRows - row )    ; col++) {
				System.out.print( "  " );  
			}
			
			// row value to be printed 
			for( int num=1; num<= row ; num++ ){
				System.out.print( row + " " );  
			}

		}
	}
}
