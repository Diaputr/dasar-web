
public class ForLoopCoordinateRepresentation {

	public static void main(String[] args) {
		int TOTAL_ROWS = 5;
		int TOTAL_COLUMNS = 5;

		for( int row = 1 ; row <= TOTAL_ROWS ; row ++ ) {
			for( int col = 1 ; col <= TOTAL_COLUMNS ; col ++ ) {
				System.out.print("(" + row + "," + col + ") ");
			}
			// moves the control to the next line and 
			// prints next row iteration value 
			System.out.println();
			System.out.println();
		}
	}

}
