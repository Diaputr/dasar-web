package strings;

public class SubStringDiamondPattern {

	public static void main(String[] args) {
		
		String str = "Programming";
		int index ;
		String subStr = "";
		int LENGTH = str.length();
		
		String revStr = "";
		for( index = LENGTH - 1; index >= 0 ; index -- ) {
			revStr =  revStr.concat( String.valueOf( str.charAt(index) ) );
		}
		System.out.println( revStr);
		System.out.println( "Length of String  = " + LENGTH);
		System.out.println( "===================");
		String mirrorStr = "";
		for( index = 1 ; index <= LENGTH ; index++) {
			subStr = str.substring(0, index);
			mirrorStr = revStr.substring(LENGTH - index,LENGTH - 1);
			System.out.println( mirrorStr + subStr);
			
		}
		// using decrementing loop in a string
		for( index = LENGTH - 1; index >= 1 ; index -- ) {
			subStr = str.substring(0, index);
			System.out.println( subStr);
			
		}
		
	}

}
